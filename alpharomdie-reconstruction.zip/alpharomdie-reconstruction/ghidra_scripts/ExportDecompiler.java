// Export Ghidra's source-like decompilation of every discovered function.
// This is analysis output, not buildable source code.
import ghidra.app.decompiler.DecompInterface;
import ghidra.app.decompiler.DecompileResults;
import ghidra.app.script.GhidraScript;
import ghidra.program.model.listing.Function;
import ghidra.program.model.listing.FunctionIterator;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;

public class ExportDecompiler extends GhidraScript {
    @Override
    protected void run() throws Exception {
        File output = new File(getScriptArgs()[0]);
        DecompInterface decompiler = new DecompInterface();
        decompiler.openProgram(currentProgram);
        int[] extraRvas = {0x1040,0x1070,0x10a0,0x10e0,0x1110,0x1120,0x1140,0x1150,
            0x13e0,0x1420,0x1460,0x14b0,0x15b0,0x16e0,0x17b0,0x1960,0x1a40,0x1ca7};
        for (int rva : extraRvas) {
            ghidra.program.model.address.Address address = currentProgram.getImageBase().add(rva);
            if (currentProgram.getFunctionManager().getFunctionAt(address) == null) {
                try {
                    disassemble(address);
                    createFunction(address, null);
                } catch (Exception exception) {
                    println("Could not create function at RVA 0x" + Integer.toHexString(rva) +
                            ": " + exception);
                }
            }
        }
        int count = 0;
        int failures = 0;
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(output))) {
            writer.write("/* Ghidra decompilation of " + currentProgram.getName() +
                         ". Function names/types are provisional. */\n\n");
            FunctionIterator functions = currentProgram.getFunctionManager().getFunctions(true);
            while (functions.hasNext()) {
                Function function = functions.next();
                if (!currentProgram.getMemory().getBlock(function.getEntryPoint()).isExecute())
                    continue;
                DecompileResults result = decompiler.decompileFunction(function, 90, monitor);
                writer.write("/* RVA 0x" + Long.toHexString(
                    function.getEntryPoint().getOffset() - currentProgram.getImageBase().getOffset()) +
                    ", " + function.getName() + " */\n");
                if (result.decompileCompleted() && result.getDecompiledFunction() != null) {
                    writer.write(result.getDecompiledFunction().getC());
                    count++;
                } else {
                    writer.write("/* DECOMPILATION FAILED: " + result.getErrorMessage() + " */\n");
                    failures++;
                }
                writer.write("\n\n");
            }
        }
        println("Exported " + count + " functions; failures: " + failures +
                "; output: " + output.getAbsolutePath());
        decompiler.dispose();
    }
}
