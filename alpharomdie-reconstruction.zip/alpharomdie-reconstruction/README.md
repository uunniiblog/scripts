# AlphaROMdiE source reconstruction

For the current build, tested games, and next-session notes, see
[HANDOFF.md](HANDOFF.md).

Target: the 32-bit `AlphaROMdiE.exe` shipped with Kajiri Kamui Kagura Akebono No Hikari. SHA-256:
`497af655fa00650db868e9aa39c9e553b75e5369537dcf14d00f347d55adb425`.
Its image base is `0x30000000`; executable entry is RVA `0x2c00`, and the exported
in-process entry `Init` is RVA `0x1cd0`.

## What is here

- `analysis/AlphaROMdiE_2013_ghidra.c`: source-like decompilation of 40 identified
  functions. Ghidra originally missed 18 custom hook functions; the export script
  explicitly recovered them. There were zero function decompilation failures.
- `analysis/AlphaROMdiE_2013_disassembly.txt`: complete section disassembly for
  checking decompiler output and inline assembly.
- `analysis/pe/`: original PE section data, resources, and a manifest of imports,
  exports, addresses, and hashes. `HookStub` contains executable trampoline data.
- `ghidra_project/`: editable Ghidra analysis database.
- `ghidra_scripts/ExportDecompiler.java` and `tools/extract_pe.py`: repeatable
  extraction tools.

The `.c` file is **decompiler output, not buildable C source**. Its inferred types,
calling conventions, missing return values, and stack variables need review before
use in a replacement. In particular, Ghidra does not translate the raw `HookStub`
machine code into portable C. The sections and disassembly preserve that code.

## Behavior map

| RVA | Role inferred from calls and decompilation |
| --- | --- |
| `0x1000` | Map a PE RVA to a file offset using section headers. |
| `0x1040`–`0x11c0` | Japanese code-page and ANSI UI conversion hooks. |
| `0x1250` | Load an NLS code-page table and install conversion hooks. |
| `0x13e0`–`0x1550` | Time-zone, locale, and version-information hooks. |
| `0x15b0`–`0x17b0` | Watch an allocation/decompression path and bypass one loader check. |
| `0x1810` | Exception handler for the protection-check patch. |
| `0x1960`, `0x1a40` | Alternative check-hook paths selected by the game PE. |
| `0x1af0` | Apply PE base relocations to the injected copy. |
| `0x1b50`, `0x1bb7` | Remote load stub and PE export lookup. |
| `0x1cd0` | `Init`: repair imports, install hooks, then load `Plugin/*.adp`. |
| `0x1fd0` | Copy the executable path and load stub into the suspended game process, then start a remote thread. |
| `0x2150` | Launch the game suspended, inject, resume it. |
| `0x2220`, `0x2320` | Shortcut creation and GUI/install dialog. |
| `0x2c00` | Executable entry point. A command-line game path bypasses the dialog. |
| `0x2cb7` | x86 instruction-length decoder. |
| `0x2f3f`, `0x30f6`, `0x3135` | API hook install, symbol lookup, and hook removal. |

## Native Linux direction

The launcher UI and process selection can become a Linux executable. The game and
its Windows API calls still run in Wine/Proton, so the code that patches the game's
address space must remain an x86 PE component or be replaced by a substantially
different Wine-aware injector. The rebuilt x86 helper now includes the former
`WineCompat.adp` fix directly. A native launcher alone cannot execute the
in-process hooks or load `.adp` plugins into a Windows game.

The practical sequence is to (1) make a buildable x86 Windows helper from the
decompilation, (2) compare its behavior against the original in Wine, (3) move
launcher/configuration work to Linux, and (4) replace individual hooks with
better-targeted Wine/Proton behavior where possible. This repository completes the
extraction and function mapping. A [first working PE32 rebuild](rebuild/README.md)
now covers the tested game's startup path; a native Linux port and the remaining
game-dependent hooks are still future work.

## Repeat the extraction

Requires Ghidra, `pefile`, and GNU `objdump`:

```sh
python3 tools/extract_pe.py /path/to/AlphaROMdiE.exe analysis/pe
objdump -D -M intel -j .text -j HookStub /path/to/AlphaROMdiE.exe > analysis/AlphaROMdiE_2013_disassembly.txt
/opt/ghidra/support/analyzeHeadless ghidra_project AlphaROMdiE \
  -process AlphaROMdiE.exe -scriptPath ghidra_scripts \
  -postScript ExportDecompiler.java analysis/AlphaROMdiE_2013_ghidra.c
```
