/* Ghidra decompilation of AlphaROMdiE.exe. Function names/types are provisional. */

/* RVA 0x1000, FUN_30001000 */

int __cdecl FUN_30001000(uint param_1,int param_2,uint param_3)

{
  int iVar1;
  uint *puVar2;
  
  iVar1 = (param_1 & 0xffff) - 1;
  if (-1 < iVar1) {
    puVar2 = (uint *)(param_2 + 0xc + iVar1 * 0x28);
    do {
      if (*puVar2 <= param_3) {
        return (*(int *)(param_2 + 0x14 + iVar1 * 0x28) - *(int *)(param_2 + iVar1 * 0x28 + 0xc)) +
               param_3;
      }
      iVar1 = iVar1 + -1;
      puVar2 = puVar2 + -10;
    } while (-1 < iVar1);
  }
  return 0;
}



/* RVA 0x1040, FUN_30001040 */

void FUN_30001040(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5,undefined4 param_6,undefined4 param_7)

{
  RtlUnicodeToCustomCPN(&DAT_30007598,param_3,param_4,param_5,param_6,param_7);
  return;
}



/* RVA 0x1070, FUN_30001070 */

void FUN_30001070(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5,undefined4 param_6,undefined4 param_7)

{
  RtlCustomCPToUnicodeN(&DAT_30007598,param_3,param_4,param_5,param_6,param_7);
  return;
}



/* RVA 0x10a0, FUN_300010a0 */

void FUN_300010a0(undefined4 param_1,undefined *param_2,int param_3,undefined4 param_4,
                 undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
                 undefined4 param_9,undefined4 param_10)

{
  if (param_3 == 0) {
    param_3 = DAT_30006808;
  }
  (*(code *)param_2)(param_3,param_4,param_5,param_6,param_7,param_8,param_9,param_10);
  return;
}



/* RVA 0x10e0, FUN_300010e0 */

void FUN_300010e0(undefined4 param_1,undefined *param_2,int param_3,undefined4 param_4,
                 undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8)

{
  if (param_3 == 0) {
    param_3 = DAT_30006808;
  }
  (*(code *)param_2)(param_3,param_4,param_5,param_6,param_7,param_8);
  return;
}



/* RVA 0x1110, FUN_30001110 */

undefined4 FUN_30001110(void)

{
  return DAT_3000680c;
}



/* RVA 0x1120, FUN_30001120 */

void FUN_30001120(undefined4 param_1,undefined4 param_2,BYTE param_3)

{
  IsDBCSLeadByteEx(DAT_30006808,param_3);
  return;
}



/* RVA 0x1140, FUN_30001140 */

undefined4 FUN_30001140(void)

{
  return DAT_30006808;
}



/* RVA 0x1150, FUN_30001150 */

void FUN_30001150(undefined4 param_1,undefined4 param_2,HWND param_3,LPCSTR param_4)

{
  char cVar1;
  int iVar2;
  uint uVar3;
  undefined4 *puVar4;
  LPCSTR pCVar5;
  WCHAR local_800;
  undefined4 local_7fe [511];
  
  local_800 = DAT_30007808;
  puVar4 = local_7fe;
  for (iVar2 = 0x1ff; iVar2 != 0; iVar2 = iVar2 + -1) {
    *puVar4 = 0;
    puVar4 = puVar4 + 1;
  }
  *(undefined2 *)puVar4 = 0;
  uVar3 = 0xffffffff;
  pCVar5 = param_4;
  do {
    if (uVar3 == 0) break;
    uVar3 = uVar3 - 1;
    cVar1 = *pCVar5;
    pCVar5 = pCVar5 + 1;
  } while (cVar1 != '\0');
  MultiByteToWideChar(DAT_30006808,0,param_4,~uVar3 - 1,&local_800,0x400);
  SetWindowTextW(param_3,&local_800);
  return;
}



/* RVA 0x11c0, FUN_300011c0 */

void FUN_300011c0(undefined4 param_1,undefined *param_2,HWND param_3,UINT param_4,WPARAM param_5,
                 LPCSTR param_6)

{
  char cVar1;
  LPWSTR lpWideCharStr;
  uint uVar2;
  uint uVar3;
  LPCSTR pCVar4;
  
  if ((param_4 == 0xc) || (param_4 == 0xc2)) {
    uVar2 = 0xffffffff;
    pCVar4 = param_6;
    do {
      if (uVar2 == 0) break;
      uVar2 = uVar2 - 1;
      cVar1 = *pCVar4;
      pCVar4 = pCVar4 + 1;
    } while (cVar1 != '\0');
    lpWideCharStr = LocalAlloc(0x40,~uVar2 * 2);
    uVar3 = 0xffffffff;
    pCVar4 = param_6;
    do {
      if (uVar3 == 0) break;
      uVar3 = uVar3 - 1;
      cVar1 = *pCVar4;
      pCVar4 = pCVar4 + 1;
    } while (cVar1 != '\0');
    MultiByteToWideChar(DAT_30006808,0,param_6,~uVar3 - 1,lpWideCharStr,~uVar2 * 2);
    SendMessageW(param_3,param_4,param_5,(LPARAM)lpWideCharStr);
    LocalFree(lpWideCharStr);
  }
  (*(code *)param_2)(param_3,param_4,param_5,param_6);
  return;
}



/* RVA 0x1250, FUN_30001250 */

undefined4 FUN_30001250(void)

{
  HFILE hFile;
  SIZE_T uBytes;
  CHAR local_104 [260];
  
  GetSystemDirectoryA(local_104,0x104);
  sprintf(local_104,s__s_c__d_nls_30006830,local_104,DAT_30006808);
  hFile = _lopen(local_104,0);
  if (hFile == -1) {
    return 0;
  }
  uBytes = _llseek(hFile,0,2);
  DAT_300077f0 = LocalAlloc(0x40,uBytes);
  _llseek(hFile,0,0);
  _lread(hFile,DAT_300077f0,uBytes);
  _lclose(hFile);
  RtlInitCodePageTable(DAT_300077f0,&DAT_30007598);
  FUN_30002f3f((byte *)RtlUnicodeToMultiByteN_exref,0x30001040,0);
  FUN_30002f3f((byte *)RtlMultiByteToUnicodeN_exref,0x30001070,0);
  FUN_30002f3f((byte *)WideCharToMultiByte_exref,0x300010a0,0);
  FUN_30002f3f((byte *)MultiByteToWideChar_exref,0x300010e0,0);
  FUN_30002f3f((byte *)IsDBCSLeadByte_exref,0x30001120,0);
  FUN_30002f3f((byte *)GetSystemDefaultLCID_exref,0x30001110,0);
  FUN_30002f3f((byte *)GetUserDefaultLCID_exref,0x30001110,0);
  FUN_30002f3f((byte *)GetSystemDefaultLangID_exref,0x30001110,0);
  FUN_30002f3f((byte *)SetWindowTextA_exref,0x30001150,0);
  FUN_30002f3f((byte *)SendMessageA_exref,0x300011c0,0);
  FUN_300030f6(s_gdi32_dll_30006814,s_GdiGetCodePage_30006820,0x30001140,0);
  SetThreadLocale(DAT_3000680c);
  return 1;
}



/* RVA 0x13e0, FUN_300013e0 */

undefined4 FUN_300013e0(undefined4 param_1,undefined *param_2,int param_3)

{
  undefined4 uVar1;
  
  uVar1 = (*(code *)param_2)(param_3);
  wcscpy((wchar_t *)(param_3 + 0x58),u_TOKYO_3000683c);
  wcscpy((wchar_t *)(param_3 + 4),u_TOKYO_3000683c);
  return uVar1;
}



/* RVA 0x1420, FUN_30001420 */

void FUN_30001420(undefined4 param_1,undefined *param_2,int param_3,int param_4,int param_5,
                 undefined4 param_6)

{
  char cVar1;
  char *pcVar2;
  
  (*(code *)param_2)(param_3,param_4,param_5,param_6);
  if ((param_3 == 0x800) && (param_4 == 1)) {
    pcVar2 = &DAT_30006848;
    do {
      cVar1 = *pcVar2;
      pcVar2[param_5 + -0x30006848] = cVar1;
      pcVar2 = pcVar2 + 1;
    } while (cVar1 != '\0');
  }
  return;
}



/* RVA 0x1460, FUN_30001460 */

undefined4
FUN_30001460(undefined4 param_1,undefined *param_2,int param_3,int param_4,wchar_t *param_5,
            undefined4 param_6)

{
  undefined4 uVar1;
  
  uVar1 = (*(code *)param_2)(param_3,param_4,param_5,param_6);
  if ((param_3 == 0x800) && (param_4 == 1)) {
    wcscpy(param_5,u_0411_30006850);
  }
  return uVar1;
}



/* RVA 0x14b0, FUN_300014b0 */

void FUN_300014b0(undefined4 param_1,undefined *param_2,char *param_3,DWORD param_4,
                 undefined4 param_5,undefined4 param_6)

{
  char *pcVar1;
  DWORD DVar2;
  CHAR local_104 [260];
  
  pcVar1 = strstr(param_3,s_kernel32_dll_3000685c);
  if (pcVar1 != (char *)0x0) {
    GetModuleFileNameA(DAT_300077f8,local_104,0x104);
    DVar2 = GetFileVersionInfoSizeA(local_104,&param_4);
    (*(code *)param_2)(local_104,param_4,DVar2,param_6);
    return;
  }
  (*(code *)param_2)(param_3,param_4,param_5,param_6);
  return;
}



/* RVA 0x1550, FUN_30001550 */

void FUN_30001550(undefined4 param_1,undefined *param_2,wchar_t *param_3,DWORD param_4,
                 undefined4 param_5,undefined4 param_6)

{
  wchar_t *pwVar1;
  DWORD DVar2;
  
  pwVar1 = wcsstr(param_3,u_kernel32_dll_3000686c);
  if (pwVar1 != (wchar_t *)0x0) {
    DVar2 = GetFileVersionInfoSizeW((LPCWSTR)&DAT_300075e8,&param_4);
    (*(code *)param_2)(&DAT_300075e8,param_4,DVar2,param_6);
    return;
  }
  (*(code *)param_2)(param_3,param_4,param_5,param_6);
  return;
}



/* RVA 0x15b0, FUN_300015b0 */

undefined4
FUN_300015b0(undefined4 param_1,code *param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8)

{
  char cVar1;
  int iVar2;
  BOOL BVar3;
  undefined4 uVar4;
  int iVar5;
  int iVar6;
  uint uVar7;
  undefined4 unaff_EBP;
  uint uVar8;
  int iVar9;
  char *pcVar10;
  
  BVar3 = IsBadReadPtr((void *)*DAT_30007588,0x104);
  if (BVar3 == 0) {
    BVar3 = IsBadReadPtr((void *)DAT_30007588[1],DAT_30007588[2]);
    if (BVar3 == 0) {
      uVar7 = 0xffffffff;
      pcVar10 = (char *)*DAT_30007588;
      do {
        if (uVar7 == 0) break;
        uVar7 = uVar7 - 1;
        cVar1 = *pcVar10;
        pcVar10 = pcVar10 + 1;
      } while (cVar1 != '\0');
      if (((short *)((char *)*DAT_30007588 + ~uVar7 + 4) == (short *)DAT_30007588[1]) &&
         (*(short *)DAT_30007588[1] == 0x5a4d)) {
        uVar4 = (*param_2)(param_3,param_4,param_5,param_6,param_7,param_8);
        FUN_30003135(DAT_300075dc);
        iVar2 = DAT_30007588[1];
        iVar9 = *(int *)(iVar2 + 0x3c) + iVar2;
        uVar7 = *(uint *)(iVar9 + 0x28);
        uVar8 = CONCAT22((short)((uint)unaff_EBP >> 0x10),*(undefined2 *)(iVar9 + 6));
        iVar6 = *(ushort *)(iVar9 + 0x14) + 0x18 + iVar9;
        iVar5 = FUN_30001000(uVar8,iVar6,uVar7);
        iVar9 = FUN_30001000(uVar8,iVar6,*(uint *)(iVar9 + 0x78));
        iVar6 = FUN_30001000(uVar8,iVar6,*(uint *)(iVar9 + 0x1c + iVar2));
        *(uint *)(iVar6 + iVar2) = uVar7 + 3;
        *(undefined4 *)(iVar5 + iVar2) = 0xc3000cc2;
        return uVar4;
      }
    }
  }
  uVar4 = (*param_2)(param_3,param_4,param_5,param_6,param_7,param_8);
  return uVar4;
}



/* RVA 0x16e0, FUN_300016e0 */

undefined4
FUN_300016e0(undefined4 param_1,undefined *param_2,undefined4 param_3,int param_4,undefined4 param_5
            ,undefined4 param_6)

{
  undefined4 uVar1;
  
  if ((DAT_30007588 == 0) && (param_4 == 0x2a0)) {
    DAT_30007588 = (*(code *)param_2)(param_3,0x2a0,param_5,param_6);
    FUN_30003135(DAT_300075dc);
    DAT_300075dc = FUN_30002f3f((byte *)ZwAllocateVirtualMemory_exref,0x300015b0,0);
    return DAT_30007588;
  }
  uVar1 = (*(code *)param_2)(param_3,param_4,param_5,param_6);
  return uVar1;
}



/* RVA 0x1760, FUN_30001760 */

undefined * FUN_30001760(undefined4 param_1,undefined *param_2,undefined4 param_3,char *param_4)

{
  BOOL BVar1;
  int iVar2;
  undefined *puVar3;
  
  BVar1 = IsBadReadPtr(param_4,9);
  if (BVar1 == 0) {
    iVar2 = _strnicmp(param_4,s_sarcheck_30006888,9);
    if (iVar2 == 0) {
      FUN_30003135(DAT_30007594);
      return FUN_30001ca7;
    }
  }
  puVar3 = (undefined *)(*(code *)param_2)(param_3,param_4);
  return puVar3;
}



/* RVA 0x17b0, FUN_300017b0 */

undefined4
FUN_300017b0(undefined4 param_1,undefined *param_2,undefined4 param_3,undefined4 param_4,int param_5
            )

{
  undefined4 uVar1;
  
  if (param_5 == 0x3ff) {
    uVar1 = (*(code *)param_2)(param_3,param_4,0x3ff);
    FUN_30003135(DAT_300075d8);
    return uVar1;
  }
  uVar1 = (*(code *)param_2)(param_3,param_4,param_5);
  return uVar1;
}



/* RVA 0x1810, FUN_30001810 */

/* WARNING: Removing unreachable block (ram,0x30001894) */

undefined4 __cdecl FUN_30001810(int *param_1,undefined4 param_2,int param_3)

{
  uint *puVar1;
  int iVar2;
  int iVar3;
  BOOL BVar4;
  int *piVar5;
  byte *pbVar6;
  byte *pbVar7;
  int iVar8;
  
  if (*param_1 == -0x7ffffffd) {
    pbVar7 = (byte *)**(undefined4 **)(param_3 + 0xc4);
    if ((DAT_300077fc != 0) && (DAT_300077f4 == 2)) {
      piVar5 = (int *)0x0;
      iVar8 = 0;
      do {
        while( true ) {
          if ((piVar5 != (int *)0x0) && (iVar8 != 0)) {
            puVar1 = (uint *)cpuid_Version_info(1);
            *(uint *)(*piVar5 + iVar8) = *puVar1 ^ DAT_300077fc;
            DAT_300077f4 = 0;
            **(undefined1 **)(param_3 + 0xb8) = DAT_300075d4;
            *DAT_30007800 = DAT_3000758c;
            return 0;
          }
          if (*pbVar7 != 0x39) break;
          iVar8 = *(int *)(pbVar7 + 2);
LAB_3000187d:
          iVar2 = FUN_30002cb7(pbVar7);
          pbVar7 = pbVar7 + iVar2;
        }
        if (*pbVar7 != 0x8b) goto LAB_3000187d;
        piVar5 = *(int **)(pbVar7 + 2);
        iVar2 = FUN_30002cb7(pbVar7);
        pbVar7 = pbVar7 + iVar2;
      } while( true );
    }
    if (DAT_300077f4 == 1) {
      iVar8 = 0;
      iVar2 = 5;
      pbVar6 = (byte *)0x0;
      do {
        if (iVar2 == 0) {
          if (iVar8 == 0) goto LAB_30001934;
          break;
        }
        if (*pbVar7 == 0xf) {
          iVar8 = *(int *)(pbVar7 + 2);
          pbVar6 = pbVar7;
        }
        iVar3 = FUN_30002cb7(pbVar7);
        pbVar7 = pbVar7 + iVar3;
        iVar2 = iVar2 + -1;
      } while (iVar8 == 0);
      pbVar7 = pbVar7 + iVar8 + 6;
      BVar4 = IsBadReadPtr(pbVar7,4);
      if ((BVar4 == 0) && (*(int *)pbVar7 == -1)) {
        pbVar6[0] = 0x90;
        pbVar6[1] = 0xe9;
        pbVar7[0] = 1;
        pbVar7[1] = 0;
        pbVar7[2] = 0;
        pbVar7[3] = 0;
        DAT_300077f4 = 0;
      }
LAB_30001934:
      **(undefined1 **)(param_3 + 0xb8) = DAT_300075d4;
      *DAT_30007800 = DAT_3000758c;
    }
  }
  return 0;
}



/* RVA 0x1960, FUN_30001960 */

void FUN_30001960(byte *param_1,undefined *param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  byte *lpAddress;
  int iVar2;
  
  if (DAT_300077f4 != 0) {
    if ((DAT_30007584 <= param_1) && (param_1 <= DAT_30007584 + DAT_30007580)) {
      iVar2 = 0;
      lpAddress = param_1;
      do {
        if ((DAT_300077fc == 0) && (*lpAddress == 0x35)) {
          DAT_300077fc = *(int *)(lpAddress + 1);
        }
        else {
          if (*lpAddress == 0xcc) {
LAB_30001a12:
            (*(code *)param_2)(param_3,param_4);
            return;
          }
          if (*lpAddress == 0xc3) {
            VirtualProtect(lpAddress,1,0x40,(PDWORD)&param_1);
            DAT_300075d4 = *lpAddress;
            *lpAddress = 0xcc;
            DAT_30007800 = (undefined4 *)((int)ExceptionList + 4);
            DAT_3000758c = *DAT_30007800;
            *DAT_30007800 = FUN_30001810;
            goto LAB_30001a12;
          }
        }
        iVar1 = FUN_30002cb7(lpAddress);
        lpAddress = lpAddress + iVar1;
        iVar2 = iVar2 + 1;
        if (0x4f < iVar2) {
          (*(code *)param_2)(param_3,param_4);
          return;
        }
      } while( true );
    }
  }
  (*(code *)param_2)(param_3,param_4);
  return;
}



/* RVA 0x1a40, FUN_30001a40 */

void FUN_30001a40(byte *param_1,undefined *param_2,undefined4 param_3)

{
  int iVar1;
  byte *lpAddress;
  int iVar2;
  
  if (DAT_300077f4 != 0) {
    if ((DAT_30007584 <= param_1) && (param_1 <= DAT_30007584 + DAT_30007580)) {
      iVar2 = 0;
      lpAddress = param_1;
      do {
        if (*lpAddress == 0xcc) {
LAB_30001acb:
          (*(code *)param_2)(param_3);
          return;
        }
        if (*lpAddress == 0xc3) {
          VirtualProtect(lpAddress,1,0x40,(PDWORD)&param_1);
          DAT_300075d4 = *lpAddress;
          *lpAddress = 0xcc;
          DAT_30007800 = (undefined4 *)((int)ExceptionList + 4);
          DAT_3000758c = *DAT_30007800;
          *DAT_30007800 = FUN_30001810;
          goto LAB_30001acb;
        }
        iVar1 = FUN_30002cb7(lpAddress);
        lpAddress = lpAddress + iVar1;
        iVar2 = iVar2 + 1;
        if (0x4f < iVar2) {
          (*(code *)param_2)(param_3);
          return;
        }
      } while( true );
    }
  }
  (*(code *)param_2)(param_3);
  return;
}



/* RVA 0x1af0, FUN_30001af0 */

undefined4 __cdecl FUN_30001af0(int param_1,int param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  ushort *puVar5;
  
  iVar2 = *(int *)(param_1 + 0x3c) + param_1;
  iVar1 = *(int *)(iVar2 + 0x34);
  piVar4 = (int *)(*(int *)(iVar2 + 0xa0) + param_1);
  do {
    puVar5 = (ushort *)(piVar4 + 2);
    do {
      if (*puVar5 != 0) {
        piVar3 = (int *)((*puVar5 & 0xfff) + param_1 + *piVar4);
        *piVar3 = *piVar3 - (iVar1 - param_2);
      }
      puVar5 = puVar5 + 1;
    } while (puVar5 < (ushort *)(piVar4[1] + (int)piVar4));
    piVar4 = (int *)((int)piVar4 + piVar4[1]);
  } while (*piVar4 != 0);
  return 1;
}



/* RVA 0x1b50, FUN_30001b50 */

void __cdecl FUN_30001b50(undefined4 param_1)

{
  code *pcVar1;
  int iVar2;
  byte local_24 [16];
  byte local_14 [8];
  byte *local_c;
  void *local_8;
  
  local_24[0xc] = 0;
  local_14[4] = 0;
  local_c = local_14;
  local_24[0] = 0x4c;
  local_24[1] = 0x6f;
  local_24[2] = 0x61;
  local_24[3] = 100;
  local_24[4] = 0x4c;
  local_24[5] = 0x69;
  local_24[6] = 0x62;
  local_24[7] = 0x72;
  local_24[8] = 0x61;
  local_24[9] = 0x72;
  local_24[10] = 0x79;
  local_24[0xb] = 0x57;
  local_14[0] = 0x49;
  local_14[1] = 0x6e;
  local_14[2] = 0x69;
  local_14[3] = 0x74;
  local_8 = Self;
  pcVar1 = (code *)FUN_30001bb7(*(int *)(*(int *)**(undefined4 **)
                                                   (*(int *)(*(int *)((int)Self + 0x30) + 0xc) + 0xc
                                                   ) + 0x18),local_24);
  iVar2 = (*pcVar1)(param_1);
  pcVar1 = (code *)FUN_30001bb7(iVar2,local_c);
  (*pcVar1)();
  return;
}



/* RVA 0x1bb7, FUN_30001bb7 */

uint FUN_30001bb7(int param_1,byte *param_2)

{
  byte bVar1;
  int *piVar2;
  int iVar3;
  uint uVar4;
  uint uVar5;
  int iVar6;
  byte *pbVar7;
  int iVar8;
  bool bVar9;
  int local_10;
  byte *local_c;
  
  piVar2 = (int *)(*(int *)(param_1 + 0x3c) + param_1);
  if (*piVar2 == 0x4550) {
    uVar5 = piVar2[0x1e] + param_1;
    if ((uVar5 != 0) && (*(int *)(uVar5 + 0x20) != 0)) {
      local_10 = 0;
      iVar6 = *(int *)(uVar5 + 0x18) + -1;
      if (-1 < iVar6) {
        do {
          local_c = param_2;
          iVar8 = (local_10 + iVar6) / 2;
          pbVar7 = (byte *)(*(int *)(*(int *)(uVar5 + 0x20) + param_1 + iVar8 * 4) + param_1);
          do {
            bVar1 = *pbVar7;
            bVar9 = bVar1 < *local_c;
            if (bVar1 != *local_c) {
LAB_30001c57:
              iVar3 = (1 - (uint)bVar9) - (uint)(bVar9 != 0);
              goto LAB_30001c5c;
            }
            if (bVar1 == 0) break;
            bVar1 = pbVar7[1];
            bVar9 = bVar1 < local_c[1];
            if (bVar1 != local_c[1]) goto LAB_30001c57;
            local_c = local_c + 2;
            pbVar7 = pbVar7 + 2;
          } while (bVar1 != 0);
          iVar3 = 0;
LAB_30001c5c:
          if (iVar3 == 0) {
            uVar4 = *(int *)(*(int *)(uVar5 + 0x1c) + param_1 +
                            (uint)*(ushort *)(*(int *)(uVar5 + 0x24) + param_1 + iVar8 * 2) * 4) +
                    param_1;
            if ((uVar5 <= uVar4) && (uVar4 < piVar2[0x1f] + uVar5)) {
              return 0;
            }
            if (uVar4 != 0) {
              return uVar4;
            }
          }
          else {
            if (local_10 == iVar6) {
              return 0;
            }
            if (iVar3 < 1) {
              local_10 = iVar8 + 1;
            }
            else {
              iVar6 = iVar8 + -1;
            }
          }
        } while (local_10 <= iVar6);
      }
    }
  }
  return 0;
}



/* RVA 0x1ca7, FUN_30001ca7 */

void FUN_30001ca7(void)

{
  return;
}



/* RVA 0x1cb0, thunk_FUN_30001cb5 */

void thunk_FUN_30001cb5(void)

{
  code *pcVar1;
  
  pcVar1 = FUN_30001cb5;
  do {
    pcVar1 = (code *)((uint)(pcVar1 + -1) & 0xffff0000);
  } while (*(short *)pcVar1 != 0x5a4d);
  return;
}



/* RVA 0x1cb5, FUN_30001cb5 */

void FUN_30001cb5(void)

{
  short *unaff_retaddr;
  
  do {
    unaff_retaddr = (short *)((int)unaff_retaddr - 1U & 0xffff0000);
  } while (*unaff_retaddr != 0x5a4d);
  return;
}



/* RVA 0x1cd0, Init */

void Init(void)

{
  word *pwVar1;
  int iVar2;
  IMAGE_DOS_HEADER *pIVar3;
  int iVar4;
  uint uVar5;
  HMODULE pHVar6;
  UINT UVar7;
  BOOL BVar8;
  uint uVar9;
  int iVar10;
  HANDLE hFindFile;
  word *pwVar11;
  word *pwVar12;
  code *pcVar13;
  code *pcVar14;
  code *local_254;
  _WIN32_FIND_DATAW _Stack_250;
  
                    /* 0x1cd0  1  Init */
  DAT_300077f8 = (IMAGE_DOS_HEADER *)thunk_FUN_30001cb5();
  if (DAT_300077f8 != &IMAGE_DOS_HEADER_30000000) {
    FUN_30001af0((int)DAT_300077f8,(int)DAT_300077f8);
  }
  local_254 = Self;
  local_254 = (code *)FUN_30001bb7(*(int *)(*(int *)**(undefined4 **)
                                                      (*(int *)(*(int *)((int)Self + 0x30) + 0xc) +
                                                      0xc) + 0x18),(byte *)s_LoadLibraryA_300068d8);
  pIVar3 = DAT_300077f8;
  pwVar11 = (word *)(DAT_300077f8->e_magic +
                    *(int *)(DAT_300077f8[1].e_magic + DAT_300077f8->e_lfanew));
  do {
    iVar4 = (*local_254)(pIVar3->e_magic + *(int *)(pwVar11 + 6));
    pwVar12 = (word *)(pIVar3->e_magic + *(int *)(pwVar11 + 8));
    uVar5 = *(uint *)pwVar12;
    if (uVar5 < 0x10001) {
      while (uVar5 != 0) {
        uVar5 = FUN_30001bb7(iVar4,(byte *)(pIVar3->e_magic + uVar5 + 2));
        *(uint *)pwVar12 = uVar5;
        pwVar1 = pwVar12 + 2;
        pwVar12 = pwVar12 + 2;
        uVar5 = *(uint *)pwVar1;
      }
    }
    iVar4 = *(int *)pwVar11;
    pwVar11 = pwVar11 + 10;
  } while (iVar4 != 0);
  GetModuleFileNameW((HMODULE)DAT_300077f8,(LPWSTR)&DAT_300075e8,0x104);
  pHVar6 = GetModuleHandleW((LPCWSTR)0x0);
  iVar4 = pHVar6[0xf].unused;
  DAT_300075e0 = pHVar6;
  UVar7 = GetACP();
  if ((UVar7 != 0x394) && (BVar8 = PathFileExistsA(s_disable_conv_300068c8), BVar8 == 0)) {
    FUN_30001250();
  }
  BVar8 = PathFileExistsA(s_other_engine_300068b8);
  if (BVar8 == 0) {
    if (*(int *)((int)&pHVar6[0x31].unused + iVar4) == 0) {
      pcVar14 = FUN_30001a40;
      DAT_300077f4 = 1;
      pcVar13 = GetDriveTypeA_exref;
    }
    else {
      pcVar14 = FUN_30001960;
      DAT_300077f4 = 2;
      pcVar13 = GetUserNameA_exref;
    }
    FUN_30002f3f((byte *)pcVar13,(int)pcVar14,0);
  }
  DisableThreadLibraryCalls((HMODULE)DAT_300077f8);
  uVar5 = 0;
  uVar9 = (uint)*(ushort *)((int)&pHVar6[5].unused + iVar4);
  iVar10 = (int)&pHVar6[6].unused + iVar4 + uVar9;
  DAT_30007584 = (LPVOID)((int)&pHVar6->unused + *(int *)((int)&pHVar6[9].unused + iVar4 + uVar9));
  DAT_30007580 = *(SIZE_T *)(iVar10 + 8);
  uVar9 = (uint)*(ushort *)((int)&pHVar6[1].unused + iVar4 + 2);
  if (uVar9 != 0) {
    do {
      uVar5 = uVar5 + 1;
      if (*(int *)(iVar10 + 1) == 0x63727372) {
        iVar2 = *(int *)(iVar10 + 0x29);
        iVar10 = iVar10 + 0x28;
        while (((iVar2 != 0x74616469 && (*(short *)(iVar10 + 5) != 0x61)) &&
               (uVar5 = uVar5 + 1, uVar5 < uVar9))) {
          iVar2 = *(int *)(iVar10 + 0x29);
          iVar10 = iVar10 + 0x28;
        }
        if ((*(int *)(iVar10 + 1) == 0x74746573) && (*(short *)(iVar10 + 5) == 0x6365)) {
          DAT_300075d8 = FUN_30002f3f((byte *)GetModuleFileNameA_exref,0x300017b0,0);
        }
        if (uVar5 < *(ushort *)((int)&pHVar6[1].unused + iVar4 + 2)) {
          DAT_300075dc = FUN_30002f3f((byte *)VirtualAlloc_exref,0x300016e0,0);
        }
        else {
          VirtualProtect(DAT_30007584,DAT_30007580,0x40,(PDWORD)&local_254);
          DAT_30007594 = FUN_30002f3f((byte *)GetProcAddress_exref,0x30001760,0);
        }
        FUN_30002f3f((byte *)GetFileVersionInfoA_exref,0x300014b0,0);
        FUN_30002f3f((byte *)GetFileVersionInfoW_exref,0x30001550,0);
        FUN_30002f3f((byte *)GetTimeZoneInformation_exref,0x300013e0,0);
        FUN_30002f3f((byte *)GetLocaleInfoA_exref,0x30001420,0);
        FUN_30002f3f((byte *)GetLocaleInfoW_exref,0x30001460,0);
        break;
      }
      iVar10 = iVar10 + 0x28;
    } while (uVar5 < uVar9);
  }
  BVar8 = SetCurrentDirectoryW(u_Plugin__300068a8);
  if (BVar8 != 0) {
    hFindFile = FindFirstFileW(u___adp_3000689c,&_Stack_250);
    if (hFindFile != (HANDLE)0xffffffff) {
      do {
        LoadLibraryW(_Stack_250.cFileName);
        BVar8 = FindNextFileW(hFindFile,&_Stack_250);
      } while (BVar8 != 0);
    }
    SetCurrentDirectoryW((LPCWSTR)&DAT_30006894);
    FindClose(hFindFile);
  }
  return;
}



/* RVA 0x1fd0, FUN_30001fd0 */

undefined4 __cdecl FUN_30001fd0(HWND param_1,HANDLE param_2)

{
  SIZE_T nSize;
  size_t sVar1;
  LPVOID lpBaseAddress;
  uint uVar2;
  uint uVar3;
  HANDLE hHandle;
  DWORD DVar4;
  LPTHREAD_START_ROUTINE lpStartAddress;
  SIZE_T local_4;
  
  local_4 = 0;
  sVar1 = wcslen((wchar_t *)&DAT_300075e8);
  nSize = sVar1 * 2 + 2;
  lpBaseAddress = VirtualAllocEx(param_2,(LPVOID)0x0,sVar1 * 2 + 0x159,0x1000,0x40);
  if (lpBaseAddress == (LPVOID)0x0) {
    MessageBoxW(param_1,(LPCWSTR)&DAT_30006918,(LPCWSTR)&DAT_30006930,0x10);
    return 0;
  }
  uVar2 = WriteProcessMemory(param_2,lpBaseAddress,&DAT_300075e8,nSize,&local_4);
  lpStartAddress = (LPTHREAD_START_ROUTINE)(nSize + (int)lpBaseAddress);
  uVar3 = WriteProcessMemory(param_2,lpStartAddress,FUN_30001b50,0x157,&local_4);
  if ((uVar2 & uVar3) == 0) {
    VirtualFreeEx(param_2,lpBaseAddress,0,0x8000);
    MessageBoxW(param_1,(LPCWSTR)&DAT_30006918,(LPCWSTR)&DAT_30006930,0x10);
    return 0;
  }
  hHandle = CreateRemoteThread(param_2,(LPSECURITY_ATTRIBUTES)0x0,0,lpStartAddress,lpBaseAddress,0,
                               &local_4);
  if (hHandle == (HANDLE)0x0) {
    VirtualFreeEx(param_2,lpBaseAddress,0,0x8000);
    MessageBoxW(param_1,(LPCWSTR)&DAT_300068e8,(LPCWSTR)&DAT_30006930,0x10);
    return 0;
  }
  DVar4 = WaitForSingleObject(hHandle,10000);
  if (DVar4 != 0) {
    TerminateThread(hHandle,0xffffffff);
    VirtualFreeEx(param_2,lpBaseAddress,0,0x8000);
    MessageBoxW(param_1,(LPCWSTR)&DAT_300068e8,(LPCWSTR)&DAT_30006930,0x10);
    return 0;
  }
  VirtualFreeEx(param_2,lpBaseAddress,0,0x8000);
  CloseHandle(hHandle);
  return 1;
}



/* RVA 0x2150, FUN_30002150 */

BOOL __cdecl FUN_30002150(HWND param_1,LPCWSTR param_2)

{
  BOOL BVar1;
  int iVar2;
  _STARTUPINFOW *p_Var3;
  _PROCESS_INFORMATION local_54;
  _STARTUPINFOW local_44;
  
  local_54.hProcess = (HANDLE)0x0;
  local_54.hThread = (HANDLE)0x0;
  local_54.dwProcessId = 0;
  p_Var3 = &local_44;
  for (iVar2 = 0x11; iVar2 != 0; iVar2 = iVar2 + -1) {
    p_Var3->cb = 0;
    p_Var3 = (_STARTUPINFOW *)&p_Var3->lpReserved;
  }
  local_54.dwThreadId = 0;
  local_44.cb = 0x44;
  BVar1 = CreateProcessW(param_2,(LPWSTR)0x0,(LPSECURITY_ATTRIBUTES)0x0,(LPSECURITY_ATTRIBUTES)0x0,0
                         ,4,(LPVOID)0x0,(LPCWSTR)0x0,&local_44,&local_54);
  if (BVar1 == 0) {
    MessageBoxW(param_1,(LPCWSTR)&DAT_30006950,(LPCWSTR)&DAT_30006930,0x10);
    return 0;
  }
  iVar2 = FUN_30001fd0(param_1,local_54.hProcess);
  if (iVar2 == 0) {
    TerminateProcess(local_54.hProcess,0);
    MessageBoxW(param_1,(LPCWSTR)&DAT_3000693c,(LPCWSTR)&DAT_30006930,0x10);
    BVar1 = 0;
  }
  else {
    ResumeThread(local_54.hThread);
  }
  CloseHandle(local_54.hThread);
  CloseHandle(local_54.hProcess);
  return BVar1;
}



/* RVA 0x2220, FUN_30002220 */

/* WARNING: Restarted to delay deadcode elimination for space: stack */

bool __cdecl FUN_30002220(wchar_t *param_1)

{
  wchar_t *pwVar1;
  HRESULT HVar2;
  int iVar3;
  int *unaff_EBX;
  undefined4 uStack_230;
  int *piVar4;
  int *local_210 [2];
  wchar_t local_208 [240];
  int *piStack_28;
  
  pwVar1 = wcsrchr(param_1,L'\\');
  uStack_230 = 0x3000224b;
  wcsncpy(local_208,param_1,(int)pwVar1 - (int)param_1 >> 1);
  uStack_230 = 0x30002267;
  HVar2 = CoCreateInstance((IID *)&DAT_30005248,(LPUNKNOWN)0x0,1,(IID *)&DAT_30005238,local_210);
  if (HVar2 < 0) {
    return false;
  }
  pwVar1 = param_1;
  (**(code **)(*local_210[0] + 0x44))();
  piVar4 = (int *)&DAT_300075e8;
  (**(code **)(*unaff_EBX + 0x50))();
  (**(code **)(*(int *)pwVar1 + 0x24))(pwVar1);
  iVar3 = *piVar4;
  pwVar1 = wcsrchr(param_1,L'\\');
  pwVar1 = pwVar1 + 1;
  (**(code **)(iVar3 + 0x2c))(piVar4);
  piVar4 = (int *)&DAT_30005258;
  iVar3 = (*(code *)*unaff_EBX)(&stack0xfffffde4,&DAT_30005258,&uStack_230);
  if (iVar3 < 0) {
    return false;
  }
  iVar3 = (**(code **)(*(int *)pwVar1 + 0x18))(pwVar1,piStack_28,2);
  (**(code **)(*piVar4 + 8))(piVar4);
  (**(code **)(*piStack_28 + 8))(piStack_28);
  return -1 < iVar3;
}



/* RVA 0x2320, FUN_30002320 */

HGDIOBJ FUN_30002320(HWND param_1,uint param_2,HDC param_3,int param_4)

{
  LONG LVar1;
  HPEN pHVar2;
  HBRUSH pHVar3;
  HFONT h;
  HDC pHVar4;
  HWND pHVar5;
  HMODULE hModule;
  FARPROC pFVar6;
  HICON lParam;
  uint uVar7;
  HGDIOBJ pvVar8;
  wchar_t *pwVar9;
  UINT UVar10;
  DWORD DVar11;
  HFILE HVar12;
  size_t sVar13;
  LPWSTR _Source;
  int iVar14;
  undefined4 *puVar15;
  COLORREF CVar16;
  wchar_t *_Str2;
  BOOL BVar17;
  tagRECT local_684;
  UINT local_674;
  LPCWSTR local_670;
  int local_66c;
  tagRECT local_668;
  tagPAINTSTRUCT local_658;
  wchar_t local_618;
  undefined4 local_616 [129];
  WCHAR local_410;
  undefined4 local_40e [129];
  wchar_t local_208;
  undefined4 local_206 [129];
  
  if (param_2 < 0x139) {
    if (param_2 == 0x138) {
      SetBkMode(param_3,1);
      SetTextColor(param_3,0xffffff);
      pvVar8 = GetStockObject(5);
      return pvVar8;
    }
    if (param_2 < 0x111) {
      if (param_2 == 0x110) {
        pHVar5 = GetDlgItem(param_1,0x3ea);
        if (pHVar5 == (HWND)0x0) {
          SetWindowTextW(param_1,(LPCWSTR)&DAT_30006ac0);
          DAT_30007804 = param_1;
        }
        else {
          SetWindowTextW(param_1,(LPCWSTR)&DAT_30006b10);
          SetDlgItemTextA(param_1,0x3f3,s_Tue_May_28_10_19_22_2013_30006af4);
          hModule = LoadLibraryA(s_USER32_dll_30006ae8);
          pFVar6 = GetProcAddress(hModule,s_ChangeWindowMessageFilter_30006acc);
          if (pFVar6 != (FARPROC)0x0) {
            (*pFVar6)(0x49,1);
            (*pFVar6)(0x233,1);
          }
        }
        lParam = LoadIconW(DAT_300075e0,(LPCWSTR)&DAT_00000066);
        SendMessageW(param_1,0x80,1,(LPARAM)lParam);
        uVar7 = GetWindowLongW(param_1,-0x14);
        SetWindowLongW(param_1,-0x14,uVar7 | 0x80000);
        SetLayeredWindowAttributes(param_1,0,0xe5,2);
        return (HGDIOBJ)0x1;
      }
      if (param_2 == 0xf) {
        GetClientRect(param_1,&local_668);
        pHVar4 = BeginPaint(param_1,&local_658);
        pHVar3 = CreateSolidBrush(0xead99a);
        SelectObject(pHVar4,pHVar3);
        pHVar2 = CreatePen(0,3,0xffffff);
        SelectObject(pHVar4,pHVar2);
        Rectangle(pHVar4,local_668.left,local_668.top,local_668.right,local_668.bottom);
        DeleteObject(pHVar3);
        DeleteObject(pHVar2);
        EndPaint(param_1,&local_658);
        return (HGDIOBJ)0x1;
      }
      if (param_2 == 0x2b) {
        pHVar4 = *(HDC *)(param_4 + 0x18);
        uVar7 = *(uint *)(param_4 + 0x10);
        local_684.left = *(int *)(param_4 + 0x1c);
        local_684.top = *(int *)(param_4 + 0x20);
        local_684.right = *(int *)(param_4 + 0x24);
        local_684.bottom = *(int *)(param_4 + 0x28);
        if ((uVar7 & 0x10) == 0) {
          CVar16 = 0xffffff;
        }
        else {
          CVar16 = 0x66ccff;
        }
        pHVar2 = CreatePen(0,3,CVar16);
        if ((uVar7 & 1) == 0) {
          CVar16 = 0xffcc66;
        }
        else {
          CVar16 = 0x6666ff;
        }
        pHVar3 = CreateSolidBrush(CVar16);
        SelectObject(pHVar4,pHVar2);
        SelectObject(pHVar4,pHVar3);
        Rectangle(pHVar4,local_684.left,local_684.top,local_684.right,local_684.bottom);
        DeleteObject(pHVar2);
        DeleteObject(pHVar3);
        SetTextColor(pHVar4,0xffffff);
        h = CreateFontW(0x12,0,0,0,0,0,0,0,1,0,0,0,0,u_simhei_30006b40);
        SelectObject(pHVar4,h);
        SetBkMode(pHVar4,1);
        GetWindowTextW(*(HWND *)(param_4 + 0x14),(LPWSTR)&local_658,0x20);
        LVar1 = local_684.left;
        local_668.top = local_684.top;
        local_668.right = local_684.right;
        local_668.bottom = local_684.bottom;
        DrawTextW(pHVar4,(LPCWSTR)&local_658,-1,&local_684,0x411);
        OffsetRect(&local_684,(((local_668.right - LVar1) - local_684.right) + local_684.left) / 2,
                   (((local_668.bottom - local_668.top) - local_684.bottom) + local_684.top) / 2);
        DrawTextW(pHVar4,(LPCWSTR)&local_658,-1,&local_684,0x11);
        DeleteObject(h);
        return (HGDIOBJ)0x1;
      }
    }
    else if (param_2 == 0x111) {
      switch((uint)param_3 & 0xffff) {
      case 1000:
        local_670 = u_http___Azure_kDays_cn_30006a94;
        break;
      case 0x3e9:
        if (local_670 == (LPCWSTR)0x0) {
          local_670 = u_mailto_Azure_52pojie_cn_30006a64;
        }
        break;
      case 0x3ea:
        if (DAT_30007804 == (HWND)0x0) {
          DialogBoxParamW(DAT_300075e0,(LPCWSTR)&DAT_00000069,(HWND)0x0,FUN_30002320,0);
          return (HGDIOBJ)0x1;
        }
        SetForegroundWindow(DAT_30007804);
        return (HGDIOBJ)0x1;
      case 0x3eb:
      case 0x3ed:
        iVar14 = 0x5ea1;
        do {
          SetLayeredWindowAttributes(param_1,0,(BYTE)(iVar14 / 100),2);
          Sleep(5);
          iVar14 = iVar14 + -0xff;
        } while (-1 < iVar14);
        PostQuitMessage(0);
        return (HGDIOBJ)0x1;
      case 0x3ec:
        PostMessageW(param_1,0x112,0xf020,0);
        return (HGDIOBJ)0x1;
      case 0x3ee:
        iVar14 = 0x5ea1;
        do {
          SetLayeredWindowAttributes(param_1,0,(BYTE)(iVar14 / 100),2);
          Sleep(5);
          iVar14 = iVar14 + -0xff;
        } while (-1 < iVar14);
        EndDialog(param_1,0);
        DAT_30007804 = (HWND)0x0;
        return (HGDIOBJ)0x1;
      default:
        goto switchD_30002676_default;
      }
      ShellExecuteW(param_1,u_open_30006a58,local_670,(LPCWSTR)0x0,(LPCWSTR)0x0,5);
      return (HGDIOBJ)0x1;
    }
  }
  else {
    if (param_2 == 0x201) {
      UVar10 = 0xa1;
    }
    else {
      if (param_2 != 0x202) {
        if (param_2 != 0x233) {
          return (HGDIOBJ)0x0;
        }
        local_410 = L'\0';
        local_618 = L'\0';
        puVar15 = local_40e;
        for (iVar14 = 0x81; iVar14 != 0; iVar14 = iVar14 + -1) {
          *puVar15 = 0;
          puVar15 = puVar15 + 1;
        }
        *(undefined2 *)puVar15 = 0;
        puVar15 = local_616;
        for (iVar14 = 0x81; iVar14 != 0; iVar14 = iVar14 + -1) {
          *puVar15 = 0;
          puVar15 = puVar15 + 1;
        }
        *(undefined2 *)puVar15 = 0;
        local_208 = L'\0';
        puVar15 = local_206;
        for (iVar14 = 0x81; iVar14 != 0; iVar14 = iVar14 + -1) {
          *puVar15 = 0;
          puVar15 = puVar15 + 1;
        }
        *(undefined2 *)puVar15 = 0;
        local_674 = DragQueryFileW((HDROP)param_3,0xffffffff,(LPWSTR)0x0,0);
        if ((1 < local_674) &&
           (iVar14 = MessageBoxW(param_1,(LPCWSTR)&DAT_30006a3c,(LPCWSTR)&DAT_30006930,0x44),
           iVar14 == 7)) {
          local_674 = 1;
        }
        local_66c = 0;
        local_670 = (LPCWSTR)0x0;
        if (local_674 != 0) {
          do {
            DragQueryFileW((HDROP)param_3,(UINT)local_670,&local_410,0x208);
            _Str2 = u__exe_30006a30;
            pwVar9 = wcsrchr(&local_410,L'.');
            iVar14 = _wcsicmp(pwVar9,_Str2);
            if (iVar14 == 0) {
              pwVar9 = wcsrchr(&local_410,L'\\');
              wcsncpy(&local_618,&local_410,(int)pwVar9 - (int)&local_410 >> 1);
              SetCurrentDirectoryW(&local_618);
              UVar10 = IsDlgButtonChecked(param_1,0x3f2);
              if (((UVar10 == 0) && (local_66c == 0)) &&
                 (DVar11 = GetFileAttributesW((LPCWSTR)&DAT_30006a28), DVar11 == 0xffffffff)) {
                iVar14 = MessageBoxW(param_1,(LPCWSTR)&DAT_300069d8,(LPCWSTR)&DAT_30006930,0x44);
                if (iVar14 != 6) goto LAB_30002b69;
                local_66c = 1;
              }
              wcscpy(&local_208,&local_410);
              wcscat(&local_208,u__lnk_300069c8);
              DeleteFileA(s_reg_ini_300069c0);
              UVar10 = IsDlgButtonChecked(param_1,0x3f2);
              if (UVar10 == 0) {
                DeleteFileA(s_other_engine_300068b8);
              }
              else {
                HVar12 = _lcreat(s_other_engine_300068b8,0);
                _lclose(HVar12);
              }
              BVar17 = 0;
              pwVar9 = wcscat(&local_618,(wchar_t *)&DAT_30007378);
              CopyFileW((LPCWSTR)&DAT_300075e8,pwVar9,BVar17);
              wcscpy((wchar_t *)&DAT_300075e8,&local_618);
              FUN_30002220(&local_410);
              UVar10 = IsDlgButtonChecked(param_1,0x3f0);
              if (UVar10 == 0) {
                DeleteFileA(s_disable_conv_300068c8);
              }
              else {
                HVar12 = _lcreat(s_disable_conv_300068c8,0);
                _lclose(HVar12);
              }
              UVar10 = IsDlgButtonChecked(param_1,0x3f1);
              if (UVar10 != 0) {
                pwVar9 = &local_618;
                for (iVar14 = 0x82; iVar14 != 0; iVar14 = iVar14 + -1) {
                  pwVar9[0] = L'\0';
                  pwVar9[1] = L'\0';
                  pwVar9 = pwVar9 + 2;
                }
                SHGetSpecialFolderPathW((HWND)0x0,&local_618,0,0);
                sVar13 = wcslen(&local_618);
                (&local_618)[sVar13] = L'\\';
                _Source = PathFindFileNameW(&local_208);
                wcscat(&local_618,_Source);
                FUN_30002220(&local_410);
              }
              iVar14 = MessageBoxW(param_1,(LPCWSTR)&DAT_300069a8,(LPCWSTR)&DAT_30006930,0x44);
              if ((iVar14 == 6) && (BVar17 = FUN_30002150(param_1,&local_410), BVar17 != 0)) {
                iVar14 = 0x5ea1;
                do {
                  SetLayeredWindowAttributes(param_1,0,(BYTE)(iVar14 / 100),2);
                  Sleep(5);
                  iVar14 = iVar14 + -0xff;
                } while (-1 < iVar14);
                PostQuitMessage(0);
              }
            }
            else {
              MessageBoxW(param_1,(LPCWSTR)&DAT_3000698c,(LPCWSTR)&DAT_30006930,0x40);
            }
LAB_30002b69:
            local_670 = (LPCWSTR)((int)local_670 + 1);
          } while (local_670 < local_674);
        }
        DragFinish((HDROP)param_3);
        return (HGDIOBJ)0x1;
      }
      UVar10 = 0xa2;
    }
    PostMessageW(param_1,UVar10,2,param_4);
  }
switchD_30002676_default:
  return (HGDIOBJ)0x0;
}



/* RVA 0x2c00, entry */

void entry(void)

{
  LPWSTR lpCmdLine;
  LPWSTR *ppWVar1;
  wchar_t *_Source;
  int *pNumArgs;
  int local_4;
  
  DAT_300075e0 = GetModuleHandleW((LPCWSTR)0x0);
  pNumArgs = &local_4;
  lpCmdLine = GetCommandLineW();
  ppWVar1 = CommandLineToArgvW(lpCmdLine,pNumArgs);
  GetModuleFileNameW(DAT_300077f8,(LPWSTR)&DAT_300075e8,0x104);
  _Source = wcsrchr((wchar_t *)&DAT_300075e8,L'\\');
  wcscpy((wchar_t *)&DAT_30007378,_Source);
  if (local_4 < 2) {
    CoInitialize((LPVOID)0x0);
    DialogBoxParamW(DAT_300075e0,(LPCWSTR)&DAT_00000068,(HWND)0x0,FUN_30002320,0);
    CoUninitialize();
  }
  else {
    FUN_30002150((HWND)0x0,ppWVar1[1]);
  }
                    /* WARNING: Subroutine does not return */
  ExitProcess(0);
}



/* RVA 0x2ca3, FUN_30002ca3 */

undefined4 __cdecl FUN_30002ca3(undefined4 *param_1,undefined4 param_2)

{
  undefined4 uVar1;
  
  LOCK();
  uVar1 = *param_1;
  *param_1 = param_2;
  UNLOCK();
  return uVar1;
}



/* RVA 0x2cb7, FUN_30002cb7 */

int FUN_30002cb7(byte *param_1)

{
  byte bVar1;
  byte *pbVar2;
  byte local_12;
  uint local_10;
  byte *local_c;
  byte local_5;
  
  local_c = param_1;
  local_10 = 0;
  while( true ) {
    local_5 = *local_c;
    pbVar2 = local_c + 1;
    local_10 = local_10 | *(uint *)(&DAT_30006b58 + (uint)local_5 * 4);
    if ((local_10 & 0x2000) != 0) {
      if ((*pbVar2 & 0x38) == 0) {
        local_10 = 0x1800;
      }
      else {
        local_10 = 0x800;
      }
    }
    if ((local_10 & 0x4000) != 0) {
      local_5 = *pbVar2;
      local_10 = *(uint *)(&DAT_30006f58 + (uint)local_5 * 4);
      pbVar2 = local_c + 2;
    }
    local_c = pbVar2;
    if (local_10 == 0xffffffff) break;
    if ((local_10 & 1) == 0) {
      if ((local_10 & 0x1000) != 0) {
        if ((local_5 & 1) == 0) {
          local_10 = local_10 | 0x10;
        }
        else {
          local_10 = local_10 | 8;
        }
      }
      pbVar2 = local_c;
      if ((local_10 & 0x800) != 0) {
        pbVar2 = local_c + 1;
        bVar1 = *local_c & 0xc0;
        local_12 = *local_c & 7;
        if (bVar1 != 0xc0) {
          if ((local_10 & 4) == 0) {
            if (bVar1 == 0x40) {
              local_10 = local_10 | 0x100;
            }
            if (bVar1 == 0x80) {
              local_10 = local_10 | 0x400;
            }
            if (local_12 == 4) {
              local_12 = *pbVar2 & 7;
              pbVar2 = local_c + 2;
            }
            local_c = pbVar2;
            pbVar2 = local_c;
            if ((local_12 == 5) && (bVar1 == 0)) {
              local_10 = local_10 | 0x400;
            }
          }
          else {
            if ((bVar1 == 0) && (local_12 == 6)) {
              local_10 = local_10 | 0x200;
            }
            if (bVar1 == 0x40) {
              local_10 = local_10 | 0x100;
            }
            if (bVar1 == 0x80) {
              local_10 = local_10 | 0x200;
            }
          }
        }
      }
      local_c = pbVar2;
      if ((local_10 & 0x80) != 0) {
        if ((local_10 & 4) == 0) {
          local_10 = local_10 | 0x400;
        }
        else {
          local_10 = local_10 | 0x200;
        }
      }
      if ((local_10 & 8) != 0) {
        if ((local_10 & 2) == 0) {
          local_10 = local_10 | 0x40;
        }
        else {
          local_10 = local_10 | 0x20;
        }
      }
      if ((local_10 & 0x100) != 0) {
        local_c = local_c + 1;
      }
      if ((local_10 & 0x200) != 0) {
        local_c = local_c + 2;
      }
      if ((local_10 & 0x400) != 0) {
        local_c = local_c + 4;
      }
      if ((local_10 & 0x10) != 0) {
        local_c = local_c + 1;
      }
      if ((local_10 & 0x20) != 0) {
        local_c = local_c + 2;
      }
      if ((local_10 & 0x40) != 0) {
        local_c = local_c + 4;
      }
      return (int)local_c - (int)param_1;
    }
    local_10 = local_10 & 0xfffffffe;
  }
  return -1;
}



/* RVA 0x2f3f, FUN_30002f3f */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

byte * FUN_30002f3f(byte *param_1,int param_2,int param_3)

{
  uint uVar1;
  int iVar2;
  byte *lpAddress;
  BOOL BVar3;
  HANDLE hProcess;
  undefined4 *puVar4;
  byte *pbVar5;
  byte *pbVar6;
  undefined *lpBuffer;
  SIZE_T nSize;
  SIZE_T *lpNumberOfBytesWritten;
  SIZE_T local_1c;
  DWORD local_18;
  byte *local_14;
  byte *local_10;
  uint local_c;
  uint local_8;
  
  local_8 = 0;
  local_10 = (byte *)0x0;
  local_1c = 0;
  if ((param_2 != 0) && (param_1 != (byte *)0x0)) {
    if (param_3 == 0) {
      local_8 = 0x1b;
      local_10 = (byte *)&DAT_30004058;
    }
    else if (param_3 == 1) {
      local_8 = 0x1d;
      local_10 = &DAT_30004073;
    }
    uVar1 = FUN_30002cb7(param_1);
    local_c = uVar1;
    for (; (int)uVar1 < 5; uVar1 = uVar1 + iVar2) {
      iVar2 = FUN_30002cb7(param_1 + uVar1);
    }
    if ((int)uVar1 < 0x11) {
      local_c = uVar1;
      lpAddress = LocalAlloc(0x40,0x58);
      BVar3 = VirtualProtect(lpAddress,0x58,0x40,(PDWORD)(lpAddress + 0x54));
      if (BVar3 != 0) {
        puVar4 = &DAT_30004000;
        pbVar5 = lpAddress;
        for (iVar2 = 0x16; iVar2 != 0; iVar2 = iVar2 + -1) {
          *(undefined4 *)pbVar5 = *puVar4;
          puVar4 = puVar4 + 1;
          pbVar5 = pbVar5 + 4;
        }
        lpAddress[0] = 0x90;
        lpAddress[1] = 0x90;
        lpAddress[2] = 0x90;
        lpAddress[3] = 0x90;
        lpAddress[4] = 0x90;
        lpAddress[5] = 0x90;
        lpAddress[6] = 0x90;
        lpAddress[7] = 0x90;
        lpAddress[8] = 0x90;
        lpAddress[9] = 0x90;
        lpAddress[10] = 0x90;
        lpAddress[0xb] = 0x90;
        lpAddress[0xc] = 0x90;
        lpAddress[0xd] = 0x90;
        lpAddress[0xe] = 0x90;
        lpAddress[0xf] = 0x90;
        local_14 = lpAddress + 0x15;
        pbVar5 = local_10;
        pbVar6 = local_14;
        for (uVar1 = local_8 >> 2; uVar1 != 0; uVar1 = uVar1 - 1) {
          *(undefined4 *)pbVar6 = *(undefined4 *)pbVar5;
          pbVar5 = pbVar5 + 4;
          pbVar6 = pbVar6 + 4;
        }
        for (uVar1 = local_8 & 3; uVar1 != 0; uVar1 = uVar1 - 1) {
          *pbVar6 = *pbVar5;
          pbVar5 = pbVar5 + 1;
          pbVar6 = pbVar6 + 1;
        }
        pbVar5 = param_1;
        pbVar6 = lpAddress;
        for (uVar1 = local_c >> 2; uVar1 != 0; uVar1 = uVar1 - 1) {
          *(undefined4 *)pbVar6 = *(undefined4 *)pbVar5;
          pbVar5 = pbVar5 + 4;
          pbVar6 = pbVar6 + 4;
        }
        for (uVar1 = local_c & 3; uVar1 != 0; uVar1 = uVar1 - 1) {
          *pbVar6 = *pbVar5;
          pbVar5 = pbVar5 + 1;
          pbVar6 = pbVar6 + 1;
        }
        pbVar5 = lpAddress + 0x46;
        *(uint *)(lpAddress + 0x50) = local_c;
        *(byte **)(lpAddress + 0x4c) = param_1;
        lpAddress[0x10] = 0xe9;
        lpAddress[0x45] = 0xe9;
        *(byte **)(lpAddress + 0x11) = param_1 + (local_c - (int)lpAddress) + -0x15;
        pbVar5[0] = 0xb6;
        pbVar5[1] = 0xff;
        pbVar5[2] = 0xff;
        pbVar5[3] = 0xff;
        _DAT_30006b51 = lpAddress + (0x40 - (int)param_1);
        if (param_3 == 0) {
          *(uint *)(lpAddress + local_8 + 0x11) = (param_2 - (int)local_14) - local_8;
        }
        else if (param_3 == 1) {
          *(undefined **)(local_14 + (local_8 - 9)) = &DAT_30002ca0;
          *(uint *)(local_14 + (local_8 - 4)) = (param_2 - (int)local_14) - local_8;
        }
        BVar3 = VirtualProtect(param_1,local_c,0x40,&local_18);
        if (BVar3 != 0) {
          lpNumberOfBytesWritten = &local_1c;
          nSize = 5;
          lpBuffer = &DAT_30006b50;
          pbVar6 = param_1;
          hProcess = GetCurrentProcess();
          WriteProcessMemory(hProcess,pbVar6,lpBuffer,nSize,lpNumberOfBytesWritten);
          VirtualProtect(param_1,local_c,local_18,&local_18);
          FUN_30002ca3((undefined4 *)pbVar5,local_14 + (-0x4a - (int)lpAddress));
          return lpAddress;
        }
      }
      LocalFree(lpAddress);
    }
  }
  return (byte *)0x0;
}



/* RVA 0x30f6, FUN_300030f6 */

void FUN_300030f6(LPCSTR param_1,LPCSTR param_2,int param_3,int param_4)

{
  HMODULE pHVar1;
  FARPROC pFVar2;
  LPCSTR lpProcName;
  
  lpProcName = param_2;
  pHVar1 = GetModuleHandleW(u_KernelBase_dll_30007358);
  pFVar2 = GetProcAddress(pHVar1,lpProcName);
  if (pFVar2 == (FARPROC)0x0) {
    pHVar1 = LoadLibraryA(param_1);
    pFVar2 = GetProcAddress(pHVar1,param_2);
  }
  FUN_30002f3f((byte *)pFVar2,param_3,param_4);
  return;
}



/* RVA 0x3135, FUN_30003135 */

undefined4 FUN_30003135(void *param_1)

{
  void *lpAddress;
  BOOL BVar1;
  HANDLE hProcess;
  LPVOID lpBaseAddress;
  void *lpBuffer;
  SIZE_T nSize;
  SIZE_T *lpNumberOfBytesWritten;
  SIZE_T local_8;
  
  lpAddress = param_1;
  BVar1 = IsBadReadPtr(param_1,0x58);
  if ((BVar1 == 0) &&
     (BVar1 = VirtualProtect(*(LPVOID *)((int)lpAddress + 0x4c),*(SIZE_T *)((int)lpAddress + 0x50),
                             0x40,(PDWORD)&param_1), BVar1 != 0)) {
    lpNumberOfBytesWritten = &local_8;
    nSize = *(SIZE_T *)((int)lpAddress + 0x50);
    lpBaseAddress = *(LPVOID *)((int)lpAddress + 0x4c);
    lpBuffer = lpAddress;
    hProcess = GetCurrentProcess();
    WriteProcessMemory(hProcess,lpBaseAddress,lpBuffer,nSize,lpNumberOfBytesWritten);
    BVar1 = VirtualProtect(*(LPVOID *)((int)lpAddress + 0x4c),*(SIZE_T *)((int)lpAddress + 0x50),
                           (DWORD)param_1,(PDWORD)&param_1);
    if (BVar1 != 0) {
      VirtualProtect(lpAddress,0x58,*(PDWORD)((int)lpAddress + 0x54),(PDWORD)((int)lpAddress + 0x54)
                    );
      LocalFree(lpAddress);
      return 1;
    }
  }
  return 0;
}



