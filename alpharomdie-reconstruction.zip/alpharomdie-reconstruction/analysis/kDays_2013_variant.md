# kDays.dll variant and BGI investigation (2026-10-23)

**Current status: fixed in the rebuilt helper.** See the final section below.
The earlier failure notes are retained as investigation history, including
the initial (superseded) suspicion of a Wine exception-unwind defect.

The 6,656-byte `kDays.dll` beside *大図書館の羊飼い* is byte-for-byte the
`kDays.dll.old` formerly present with Rewrite PLUS. SHA-256:
`ece31ccca4a1b30ff7dabb8a9b7709453466ef8db1b723012af678349431a23f`.
It is an Azure-packed PE32 DLL. The first 0x9000 bytes of its image starting
at RVA 0x1000, after its process attach routine unpacked it, are preserved in
[`kDays_2013_runtime_sections.bin`](kDays_2013_runtime_sections.bin). This is a
memory-section dump, not a complete PE file. The original on-disk DLL remains
in the game directory. The dump contains readable code and strings, including
`other_engine`, `GetDriveTypeA`, `GetUserNameA`, `VirtualAlloc`, and
`GetTimeZoneInformation`; much of its first routine matches the 2013
AlphaROMdiE executable's code. The runtime base during capture was
approximately `0x7b270000`; subtract `0x7b271000` from recorded code addresses
to get offsets into the dump.

## Distinct protection path

The DLL's `GetDriveTypeA` callback at runtime address `0x7b271380` differs
from the standalone AlphaROMdiE mode 1 callback. It scans up to 0x50 bytes
from the API caller for bytes `33 cc`, then an `e8` call. It reads a signed
offset at call+7, adds that to the `GetDriveTypeA` path argument to locate a
pointer to branch code, searches that code for `0f` (a long conditional jump),
and changes a `0xffffffff` sentinel at branch+12+displacement to 1. It does
not use the standalone executable's breakpoint path for this mode. The
callback is selected when the game PE field at NT headers+0xc4 is zero and
the file `other_engine` is absent. This is a useful future implementation
target, but it was **not triggered by the tested BGI.exe**.

## BGI evidence

- Game: `/home/uni/.local/share/lvnm/prefixes/protonge11-7/drive_c/August/大図書館の羊飼い/BGI.exe`.
  Original SHA-256 `d4549b85d4f8c020d7660f5f94bd1588e4a171bffd90e9e3bbde41ccb8fe62f5`.
  `BGI-kdays.exe` differs from it by just five bytes: the imported DLL name
  `IMM32` was replaced with `kDays`. The user's successful `/home/uni/steam-default.log`
  proves that this file and the original `kDays.dll` reach the title screen
  with GE-Proton 10-25 and prefix `~/.local/share/lvnm/prefixes/ge10.25/pfx`.
  The game files live under a *different* prefix directory, `protonge11-7`,
  but Wine maps that path through `X:`. The mounted game disc was present.
- The rebuilt helper in mode 1 observes `GetDriveTypeA` caller `0x0044e8e7`.
  That caller starts with `33 c9`, not the kDays `33 cc` signature. Its calls
  enumerate A: through Z:; mounted disc `D:` returns 5 (`DRIVE_CDROM`). The
  helper's standalone mode 1 breakpoint triggers during a shutdown-looking
  caller and finds no matching branch. Therefore the proposed kDays sentinel
  patch did not apply to this observed path.
- The rebuilt launcher gets through the embedded PE loader patch and opens a
  black BGI window, then an empty `Error!!` or Microsoft Visual C++ Runtime
  Library dialog under GE-Proton 11-7. The original AlphaROMdiE executable
  (SHA-256 `497af655...425`) with the known `WineCompat.adp` plugin reaches
  the same error. A copied `bgm_0502_head` from `data05000.arc` did not resolve
  the issue; the archive itself contains that entry. Forcing WineD3D and
  disabling both NTSync and FSync also failed to reach the title.
- `LANG=ja_JP.UTF-8` alone leaves Wine's ANSI code page at 1252 in this
  prefix. `HOST_LC_ALL=ja_JP.UTF-8` makes it 932 and changes the visible
  failure from `Error!!` to a Visual C++ runtime dialog; it still does not
  make the game playable. The rebuilt Japanese conversion hooks are skipped
  when Wine already reports code page 932, while the time-zone hook remains.
- An isolated reflink copy of the prefix was tried with GE-Proton 10-25, but
  Proton warned that downgrading the prefix version was invalid. Those runs
  did not establish a reliable older-runner baseline. The temporary prefixes
  were removed afterward.

## Follow-up with a working control

- Use `HOST_LC_ALL=ja_JP.UTF-8` and unset a conflicting inherited `LC_ALL`.
  Otherwise the Japanese game directory becomes `????????` in the Windows
  process, making the game exit before the protection comparison is useful.
- With the actual GE-Proton 10-25 runner and `ge10.25` prefix, the existing
  rebuilt launcher (`AlphaROMdiE-Rebuilt.exe --debug BGI.exe`) reached the
  full title menu. This was visually checked after about 30 seconds. The
  original `BGI-kdays.exe` with the original `kDays.dll` reached the same menu.
- With the proper `protonge11-7` prefix and GE-Proton 11-7, the rebuilt
  launcher opened the game window but showed a Visual C++ Runtime Library
  dialog. The original `kDays.dll` path also failed. A GE-Proton 11-9 run on a
  migrated clone failed similarly, but Proton called that clone's version
  invalid, so it is not a clean runner-only comparison.
- A patched `kDays.dll` that imports `WineCompat.dll` advanced through the
  startup warning under GE-Proton 11-7, but then froze on a black window.
  Crucially, the same patched DLL also produced a black window with the
  *working* GE-Proton 10-25 runner; it is not a valid BGI fix. The experiment
  was removed from the game and from the rebuilt release.
- GE-Proton 11-7 with the patched DLL reached a normal C++ exception while
  searching for `bgm_0502_head` outside `data05000.arc`. This lookup and
  exception also occur in the successful GE-Proton 10-25 trace. On GE-Proton
  11-7, a subsequent single-step exception in game-generated code led to
  repeated `RtlUnwind` failures at the 32-bit Wine syscall dispatcher's `iret`
  and eventually a stack overflow. Supplying an external copy of the archive
  entry and disabling NTSync did not reach the title. This points to a Wine
  exception-handling difference; it does not establish the exact Wine defect.
- The generic rebuilt `--patch BGI.exe` generated a same-process EXE, but
  that EXE also remained black under GE-Proton 10-25. The BGI game may check
  its modified PE, but that has not been proved. The unsuccessful generated
  EXEs were removed; the original `BGI.exe` and `kDays.dll` hashes match the
  values above. The existing generated launcher `BGI.AlphaROMdiE.exe` remains
  available, but this follow-up validated the main rebuilt launcher command.

At that stage the verified route was GE-Proton 10-25 with the `ge10.25` prefix and
either the original `BGI-kdays.exe` or the rebuilt launcher targeting
`BGI.exe`. GE-Proton 11-7 remains unresolved; do not claim the companion
`WineCompat.dll` or same-process EXE as working fixes for this BGI title.

## Root cause and implemented fix

Fresh GE11-7 runs with the rebuilt launcher reproduced the C++ exception at
the archive lookup. Its game handler at `004AF081` enters the statically
linked C++ runtime. When copying the caught exception, that runtime calls
`IsBadReadPtr` via IAT slot `004B1190` (and `IsBadWritePtr` via `004B1194`).
The protection redirects these slots into its generated API copies. In the
captured run, the read-probe copy began at `0728014E`.

GDB showed the real Wine `IsBadReadPtr` at `7BE4D0A0`. At +0x3f it has
`movq %xmm0,0x18(%esp)` (`66 0F D6 ...`), initializing the exception frame
before `__wine_setjmpex`. The protection's old decoder splits this instruction
and inserts obfuscation bytes inside it. In one run the generated code at
`07280470` decoded as `movq %xmm4,-0x4f(%eax)`, followed by an unintended INT3.
Another run faulted on a privileged instruction; different random junk explains
the varying symptoms. The unwind and stack-overflow failures are consequences
of corrupted code/SEH setup, not evidence of an independent Wine unwind bug.

`rebuild/src/wine_compat.c` now reuses the USER32 forwarding implementation for
**only KERNEL32 IsBadReadPtr and IsBadWritePtr**. Each selected export points
to `push original_address; ret`. The protection can copy these instructions,
then Wine executes its original probe code, retaining its normal memory checks
and exception handlers. No exception is swallowed, and no Wine binary or
original game file is modified. The helper is still embedded in the launcher;
there is no additional plugin to install.

Validation using matching, existing runner prefixes, Japanese locale, and
the mounted DAITO disc:

- GE-Proton 11-7 + rebuilt launcher: title menu visually confirmed.
- GE-Proton 11-7 + freshly generated same-process EXE: title menu confirmed.
- GE-Proton 11-9 + same-process EXE: title menu confirmed by a timed
  35-second screenshot, using the existing matching `ge11-9` prefix.
- GE-Proton 10-25 + rebuilt launcher: title menu confirmed (regression check).
- `tests/wine_compat_probes.c` under GE11-7: all 14 original/forwarded pointer
  comparisons passed, including read-only, inaccessible and cross-page memory
  and recovery from actual access violations. It also verifies the exported
  pointers changed under Wine.

These are startup checks, not full playthroughs. Previous generated launchers
and patched EXEs retain their old embedded/imported helper and must be regenerated.
The original BGI.exe and kDays.dll still match the hashes above. The old
separately patched kDays DLL has not been updated by this change.

Diagnostic work is outside the source tree at
`/home/uni/alpharomdie-debug/bgi-20261023/`. This includes the run harness,
pre-fix disassembly (`isbadread11.txt`, `api11.txt`, `inspect11b.txt`), generated
code dump (`code11.bin`), baseline/fixed logs, test result, and title captures.
The user log had changed to a failing GE11-7 original-kDays run when this
follow-up began; its preserved copy is `user-ge11-kdays.log`. Do not assume
`/home/uni/steam-default.log` still contains the earlier successful GE10 run.

Release EXE SHA-256: `a279934abd21645486083733c2a4bce1daf2a73266dae58952a76e1ac57fff76`.
Helper SHA-256: `f7606e9928cfcb27664d4dda2826bceeecfd0f9425fc9758e2673504eaf40a8e`.
The regenerated game-directory outputs are `BGI.AlphaROMdiE.exe` (launcher)
and `BGI.AlphaROMdiE.native.exe` (same process), which imports
`AlphaROMdiE.Inject.bb50e3c8ec380557.dll`. The old generated launcher and
previous build are backed up in the external debug directory.

## Direct `--generate` command check

The user-specified command using standalone Wine 11.20 and
`rebuild/bin/AlphaROMdiE-Rebuilt.exe --generate BGI.exe` succeeded and produced
`BGI.AlphaROMdiE.exe` beside the game. The generated EXE begins with the
current launcher bytes and its PE RCDATA resource 101 is byte-for-byte the
fixed helper (SHA-256 `f7606e99...40a8e`). Its target overlay names `BGI.exe`.
Launched directly under GE-Proton 11-7 with the matching prefix, Japanese
locale, and DAITO disc, it installed both USER32 and KERNEL32 forwarding
(the log reports 974 and 2 exports) and visually reached the title menu in a
35-second capture. This path needs no standalone helper DLL. The `--generate`
implementation already copies the current launcher, which embeds the same
helper used by `--patch`; no code change was necessary for this path.
