#!/usr/bin/env python3
"""Extract reproducible PE data needed to review the AlphaROMdiE decompilation."""
import hashlib
import json
import pathlib
import sys

import pefile


def main() -> None:
    binary = pathlib.Path(sys.argv[1]).resolve()
    destination = pathlib.Path(sys.argv[2]).resolve()
    destination.mkdir(parents=True, exist_ok=True)
    raw = binary.read_bytes()
    pe = pefile.PE(data=raw)

    sections = []
    for section in pe.sections:
        name = section.Name.rstrip(b"\0").decode("ascii", "replace")
        data = section.get_data()
        (destination / f"section_{name}.bin").write_bytes(data)
        sections.append({
            "name": name,
            "rva": section.VirtualAddress,
            "virtual_size": section.Misc_VirtualSize,
            "raw_size": section.SizeOfRawData,
            "sha256": hashlib.sha256(data).hexdigest(),
        })

    imports = {}
    for descriptor in getattr(pe, "DIRECTORY_ENTRY_IMPORT", []):
        dll = descriptor.dll.decode("ascii", "replace")
        imports[dll] = [entry.name.decode("ascii", "replace") if entry.name else
                        f"ordinal:{entry.ordinal}" for entry in descriptor.imports]

    exports = []
    if hasattr(pe, "DIRECTORY_ENTRY_EXPORT"):
        exports = [{"name": symbol.name.decode("ascii", "replace") if symbol.name else None,
                    "rva": symbol.address} for symbol in pe.DIRECTORY_ENTRY_EXPORT.symbols]

    resources = []
    if hasattr(pe, "DIRECTORY_ENTRY_RESOURCE"):
        for type_entry in pe.DIRECTORY_ENTRY_RESOURCE.entries:
            type_name = str(type_entry.name or type_entry.id)
            for name_entry in type_entry.directory.entries:
                name = str(name_entry.name or name_entry.id)
                for lang_entry in name_entry.directory.entries:
                    payload = lang_entry.data.struct
                    data = pe.get_data(payload.OffsetToData, payload.Size)
                    output_name = f"resource_{type_name}_{name}_{lang_entry.id}.bin"
                    (destination / output_name).write_bytes(data)
                    resources.append({"type": type_name, "name": name,
                                      "language": lang_entry.id, "file": output_name,
                                      "size": len(data)})

    manifest = {
        "binary": str(binary), "sha256": hashlib.sha256(raw).hexdigest(),
        "image_base": pe.OPTIONAL_HEADER.ImageBase,
        "entry_rva": pe.OPTIONAL_HEADER.AddressOfEntryPoint,
        "sections": sections, "imports": imports, "exports": exports,
        "resources": resources,
    }
    (destination / "manifest.json").write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(f"Extracted {len(sections)} sections and {len(resources)} resources")


if __name__ == "__main__":
    main()
