# AlphaROMdiE rebuilt launcher: first working build

This is a source-built 32-bit Windows launcher and PE patch generator with an
embedded helper for Wine/Proton.
It replaces the original `AlphaROMdiE.exe` startup path for the tested game. It
does not load the original AlphaROMdiE binary at runtime. The USER32 forwarding
fix formerly supplied by `WineCompat.adp` is compiled into the injected DLL.

## Use with Kajiri Kamui Kagura Akebono No Hikari

Copy `AlphaROMdiE-Rebuilt.exe` from `package/` beside `malie.exe`. No separate
DLL or `WineCompat.adp` file is needed. Keep other existing `.adp` files in
`Plugin`; if an old `WineCompat.adp` is present, the rebuilt helper skips it
after its built-in fix succeeds.
Launch `AlphaROMdiE-Rebuilt.exe malie.exe` under Wine or Proton. To launch
without arguments, place an `AlphaROMdiE-Rebuilt.ini` file beside the EXE with
`[launcher]` on the first line and `Target=malie.exe` on the second. The original
`AlphaROMdiE.exe` can remain in place.

You can also pass a path directly:

```text
AlphaROMdiE-Rebuilt.exe malie.exe
AlphaROMdiE-Rebuilt.exe --debug malie.exe
```

Normal launch exits after the game initializes. The embedded helper is cached
in Wine's temporary directory by content hash so the game can keep it loaded.
`--debug` keeps the launcher open until the game exits, prints the exit code,
and writes `AlphaROMdiE.Inject.log` beside the game's executable. The log is
diagnostic only. `--wait` remains available to wait and print the exit code
without enabling logging.
For another game, edit `Target=` in the `.ini` or supply its `.exe` path. The
launcher sets the game's working directory to the directory containing that `.exe`.

## Generate a directly launchable EXE

Run the rebuilt launcher once with the game executable:

```text
AlphaROMdiE-Rebuilt.exe --generate SiglusEngine.exe
```

This creates `SiglusEngine.AlphaROMdiE.exe` beside `SiglusEngine.exe`. Launch the
generated EXE directly under Wine or Proton; it remembers the target and needs
no command-line target, INI, separate DLL, or `WineCompat.adp`. The original game
EXE must remain beside it. The generated EXE is a self-contained launcher; it
does not rewrite the original game's code. `--debug` on the generated EXE
enables logging and waits for the game. Other arguments are forwarded to the
game. To choose a filename, add `OUTPUT.exe` after the game EXE; the output
must stay in the game's directory. Generation never overwrites an existing
file.

Generation accepts 32-bit Windows executables. It can create a launcher for
any such EXE, but running the game still depends on which AlphaROM protection
path it uses. Games outside the currently implemented paths need separate
validation and possibly additional hooks.

## Generate a same-process game EXE

To make the game itself own the final PID and window, run:

```text
AlphaROMdiE-Rebuilt.exe --patch malie.exe
```

This writes `malie.AlphaROMdiE.native.exe` and a versioned
`AlphaROMdiE.Inject.*.dll` beside the original. The new EXE is a patched copy
of the game: its PE entrypoint imports and calls the helper before entering the
original game code. Run that EXE directly. To choose the output name, add it as
the last argument, for example `--patch malie.exe malie.AlphaROMdiE.exe`.
The original game EXE remains intact, and the generator refuses to overwrite
an existing output. Keep the generated DLL beside the patched EXE. Set
`ALPHAROMDIE_DEBUG=1` to write `AlphaROMdiE.Inject.log` during a patched run.

This mode requires a PE32 x86 game with room for an additional section header.
It changes the game's PE headers and imports, so games that verify their own
on-disk image may reject it. Use `--generate` when that happens.

## Build

From this directory, run `bash build.sh`. It requires `i686-w64-mingw32-gcc`
and `i686-w64-mingw32-windres`. The build compiles the DLL and embeds it as a
resource in the EXE. The single EXE is in `package/`. `src/decoder_tables.h`
is data recovered from the original executable.

## Implemented behavior

- Cache the embedded helper in the temporary directory, launch the game
  suspended, inject the helper, call `Init`, resume, and exit. The cache uses
  one DLL file per helper build.
- In `--patch` mode, copy the game EXE, add an import and entry stub, and call
  the same helper within the game's own process before its original entrypoint.
- Apply the USER32 forwarding fix directly inside the injected DLL before the
  game starts, and load any other `Plugin/*.adp` files.
- Hook the old protection checks through `GetDriveTypeA` or `GetUserNameA`.
- Watch the virtual allocation used by this game's embedded PE loader and patch
  its entry and first export as the original does.
- Load the Japanese NLS table and apply the code-page, locale, and time-zone
  hooks needed when the Wine prefix reports ANSI code page 1252.

## Validation

The rebuilt DLL and launcher compiled with `-Werror`. A controlled 32-bit test
program completed with exit code zero after the rebuilt protection breakpoint
was armed and handled, and verified that `CP_ACP` decoded Shift-JIS bytes to
U+3042. The no-argument `.ini` launch path was also tested. A separate test
with no `.adp` file present confirmed that the built-in fix installed USER32
forwarding exports and the game-side protection breakpoint still completed.

For the full game, the integrated version skipped an existing `WineCompat.adp`,
patched the embedded PE loader check, and reached the game's 1024×600 `APP`
window with GE-Proton 10-34, GE-Proton 11-9, and standalone Wine 11.20. A longer
GE-Proton 10-34 run reached the same intro/media trace marker as the original
launch, without a fatal exception. A complete playthrough has not been tested.

For Angel Beats, the first distributed EXE stopped because its companion DLL
was missing from the game folder. This version embeds that helper. With
GE-Proton 11-7 and the game's existing prefix, it reached `GetUserNameA`,
patched the CPUID check, handled the protection breakpoint, and stayed running
until the 35-second test limit. A complete playthrough has not been tested.

For the launcher lifecycle, a 5-second test game started successfully in normal
mode while the launcher returned before the game finished; the game then exited
normally and the existing log timestamp stayed unchanged. Under `--debug`, the
launcher waited for exit code zero and wrote the helper log.

A generated standalone EXE launched the 32-bit smoke game without an INI or
target argument and produced the expected protection and Japanese conversion
results. A generated Angel Beats EXE also started `SiglusEngine.exe` under
GE-Proton 11-7 with no target argument.

The same-process mode completed a 32-bit test program under Wine. With
GE-Proton 11-7, the patched Angel Beats title-menu window and the patched game
EXE both used PID 545480. With standalone Wine, the patched Kajiri game windows
and patched game EXE both used PID 544729; the embedded loader patch completed
and the run reached media playback. With GE-Proton 10-34, the patched Kajiri
game windows and EXE both used PID 548291. The game checks were time-limited,
not complete playthroughs.

Rewrite+ exposed a time-zone bug: the older helper reported `TOKYO` as the
zone name but kept Wine's local UTC offset and daylight-saving rules. The
helper now reports Japan Standard Time consistently (UTC+9, no daylight
saving), including when Japanese code-page conversion hooks are skipped.
Under GE-Proton 11-9, the patched Rewrite+ EXE reached its game window with
the window and EXE sharing a PID; the generated launcher reached the same
window. Both checks ran without a `TZ` environment variable and were
time-limited rather than full playthroughs.

This is the first functional rebuild for this game's path. It does not yet
recreate the original installation GUI, shortcut creation, version-information
hooks, or every section-dependent hook used by other games. Those paths need
game-specific validation before this can replace AlphaROMdiE broadly. The helper
is still PE32 code inside Wine/Proton; a native Linux launcher can be added
around it later.

For *大図書館の羊飼い* (`BGI.exe`), the 2026-10-23 update also forwards
KERNEL32's `IsBadReadPtr` and `IsBadWritePtr`. The protection's instruction
decoder corrupts an SSE instruction in newer Wine's pointer-probe code,
causing a runtime error or black window when BGI handles a C++ exception.
The forwarding preserves Wine's original pointer validation and SEH behavior.
The updated launcher and `--patch` same-process EXE both reached the title
menu on GE-Proton 11-7. The same-process EXE also reached the title menu on
GE-Proton 11-9; the updated launcher reached it on GE-Proton
10-25. These are startup checks, not full playthroughs. Regenerate existing
launchers and patched EXEs to include this fix; an old generated EXE embeds
or imports its old helper. Keep Japanese locale and the mounted game disc.
See [`../analysis/kDays_2013_variant.md`](../analysis/kDays_2013_variant.md)
in the source tree for the evidence and diagnostic procedure.

The focused forwarding test can be compiled separately:

```
i686-w64-mingw32-gcc -O2 -Wall -Wextra -Werror tests/wine_compat_probes.c src/wine_compat.c -o /tmp/wine_compat_probes.exe
```

Run the result under Wine/Proton. It compares original and forwarded probes
for null, writable, read-only, inaccessible, and cross-page memory, including
recovery from access violations.

The exact `wine rebuild/bin/AlphaROMdiE-Rebuilt.exe --generate BGI.exe` command
was verified separately. Its output embeds the fixed helper and reached BGI's
title menu on GE-Proton 11-7 when launched directly. `--generate` refuses to
overwrite an existing output; move or remove an older generated EXE first.
