#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <shellapi.h>
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <wchar.h>
#include "patch_pe.h"

static int fail(const wchar_t *step);

typedef struct {
    char magic[8];
    uint32_t target_bytes;
    uint32_t checksum;
} TargetTrailer;

static const char target_magic[8] = {'A', 'R', 'D', 'I', 'E', 'G', '0', '1'};

static uint32_t target_checksum(const void *data, DWORD size) {
    const BYTE *bytes = data;
    uint32_t hash = UINT32_C(2166136261);
    for (DWORD i = 0; i < size; i++) {
        hash ^= bytes[i];
        hash *= UINT32_C(16777619);
    }
    return hash;
}

/* A generated EXE stores the target basename in a small PE overlay. */
static int read_embedded_target(const wchar_t *self, wchar_t *target) {
    HANDLE file = CreateFileW(self, GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_DELETE,
                              NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
    if (file == INVALID_HANDLE_VALUE) return -1;
    LARGE_INTEGER size, position;
    TargetTrailer trailer;
    DWORD received = 0;
    int result = 0;
    if (!GetFileSizeEx(file, &size)) { result = -1; goto done; }
    if (size.QuadPart < (LONGLONG)sizeof(trailer)) goto done;
    position.QuadPart = -(LONGLONG)sizeof(trailer);
    if (!SetFilePointerEx(file, position, NULL, FILE_END) ||
        !ReadFile(file, &trailer, sizeof(trailer), &received, NULL) ||
        received != sizeof(trailer)) { result = -1; goto done; }
    if (memcmp(trailer.magic, target_magic, sizeof(target_magic)) != 0) goto done;
    if (trailer.target_bytes < sizeof(wchar_t) ||
        trailer.target_bytes > MAX_PATH * sizeof(wchar_t) ||
        trailer.target_bytes % sizeof(wchar_t) != 0 ||
        size.QuadPart < (LONGLONG)(sizeof(trailer) + trailer.target_bytes)) {
        result = -1; goto corrupt;
    }
    position.QuadPart = -(LONGLONG)(sizeof(trailer) + trailer.target_bytes);
    if (!SetFilePointerEx(file, position, NULL, FILE_END) ||
        !ReadFile(file, target, trailer.target_bytes, &received, NULL) ||
        received != trailer.target_bytes) { result = -1; goto done; }
    if (target[trailer.target_bytes / sizeof(wchar_t) - 1] != L'\0' ||
        wcslen(target) != trailer.target_bytes / sizeof(wchar_t) - 1 ||
        wcspbrk(target, L"\\/:") ||
        target_checksum(target, trailer.target_bytes) != trailer.checksum) {
        result = -1; goto corrupt;
    }
    result = 1;
    goto done;
corrupt:
    SetLastError(ERROR_INVALID_DATA);
done:
    CloseHandle(file);
    return result;
}

static BOOL is_pe32_executable(const wchar_t *path) {
    HANDLE file = CreateFileW(path, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING,
                              FILE_ATTRIBUTE_NORMAL, NULL);
    if (file == INVALID_HANDLE_VALUE) return FALSE;
    IMAGE_DOS_HEADER dos;
    IMAGE_NT_HEADERS32 nt;
    DWORD received = 0;
    LARGE_INTEGER offset;
    BOOL okay = ReadFile(file, &dos, sizeof(dos), &received, NULL) &&
                received == sizeof(dos) && dos.e_magic == IMAGE_DOS_SIGNATURE && dos.e_lfanew > 0;
    if (okay) {
        offset.QuadPart = dos.e_lfanew;
        okay = SetFilePointerEx(file, offset, NULL, FILE_BEGIN) &&
               ReadFile(file, &nt, sizeof(nt), &received, NULL) && received == sizeof(nt) &&
               nt.Signature == IMAGE_NT_SIGNATURE &&
               nt.FileHeader.Machine == IMAGE_FILE_MACHINE_I386 &&
               nt.OptionalHeader.Magic == IMAGE_NT_OPTIONAL_HDR32_MAGIC;
    }
    CloseHandle(file);
    if (!okay) SetLastError(ERROR_BAD_EXE_FORMAT);
    return okay;
}

static int generate_launcher(const wchar_t *self, const wchar_t *game_argument,
                             const wchar_t *output_argument) {
    wchar_t target[MAX_PATH], output[MAX_PATH], output_name[MAX_PATH];
    DWORD length = GetFullPathNameW(game_argument, MAX_PATH, target, NULL);
    if (!length || length >= MAX_PATH) return fail(L"resolve game path");
    if (!is_pe32_executable(target)) return fail(L"validate 32-bit game EXE");
    wchar_t *slash = wcsrchr(target, L'\\');
    if (!slash || !slash[1]) return 2;
    const wchar_t *basename = slash + 1;
    if (!output_argument) {
        wcscpy(output, target);
        wchar_t *dot = wcsrchr(output, L'.');
        if (!dot || _wcsicmp(dot, L".exe") != 0) {
            fwprintf(stderr, L"Target must have an .exe filename.\n");
            return 2;
        }
        int count = swprintf(dot, MAX_PATH - (dot - output), L".AlphaROMdiE.exe");
        if (count < 0 || count >= MAX_PATH - (dot - output))
            return fail(L"build output path");
    } else {
        length = GetFullPathNameW(output_argument, MAX_PATH, output, NULL);
        if (!length || length >= MAX_PATH) return fail(L"resolve output path");
        wcscpy(output_name, output);
        wchar_t *output_slash = wcsrchr(output_name, L'\\');
        if (!output_slash) return 2;
        *output_slash = L'\0';
        wchar_t game_directory[MAX_PATH];
        wcscpy(game_directory, target);
        game_directory[slash - target] = L'\0';
        if (_wcsicmp(game_directory, output_name) != 0) {
            fwprintf(stderr, L"Generated EXE must be placed beside the game EXE.\n");
            return 2;
        }
    }
    if (_wcsicmp(target, output) == 0 || _wcsicmp(self, output) == 0) {
        fwprintf(stderr, L"Generated EXE must have a different name.\n");
        return 2;
    }
    if (!CopyFileW(self, output, TRUE)) return fail(L"copy launcher (output may already exist)");

    HANDLE file = CreateFileW(output, FILE_APPEND_DATA, 0, NULL, OPEN_EXISTING,
                              FILE_ATTRIBUTE_NORMAL, NULL);
    if (file == INVALID_HANDLE_VALUE) { fail(L"open generated EXE"); DeleteFileW(output); return 1; }
    TargetTrailer trailer;
    memcpy(trailer.magic, target_magic, sizeof(target_magic));
    trailer.target_bytes = (DWORD)((wcslen(basename) + 1) * sizeof(wchar_t));
    trailer.checksum = target_checksum(basename, trailer.target_bytes);
    DWORD written = 0;
    BOOL okay = WriteFile(file, basename, trailer.target_bytes, &written, NULL) &&
                written == trailer.target_bytes &&
                WriteFile(file, &trailer, sizeof(trailer), &written, NULL) &&
                written == sizeof(trailer);
    CloseHandle(file);
    if (!okay) { fail(L"write generated EXE"); DeleteFileW(output); return 1; }
    wprintf(L"Created %ls for %ls\n", output, basename);
    return 0;
}

static int fail(const wchar_t *step) {
    fwprintf(stderr, L"AlphaROMdiE rebuild: %ls failed (Win32 error %lu)\n", step, GetLastError());
    return 1;
}

static BOOL wait_remote(HANDLE process, LPTHREAD_START_ROUTINE start, void *argument, DWORD *result) {
    HANDLE thread = CreateRemoteThread(process, NULL, 0, start, argument, 0, NULL);
    if (!thread) return FALSE;
    DWORD waited = WaitForSingleObject(thread, 15000);
    BOOL okay = waited == WAIT_OBJECT_0 && GetExitCodeThread(thread, result);
    CloseHandle(thread);
    return okay;
}

/* Cache the embedded helper by content so the launcher may exit while it is loaded. */
static BOOL cache_helper(wchar_t *path, size_t capacity) {
    HRSRC resource = FindResourceW(NULL, MAKEINTRESOURCEW(101), RT_RCDATA);
    if (!resource) return FALSE;
    HGLOBAL loaded = LoadResource(NULL, resource);
    if (!loaded) return FALSE;
    const BYTE *bytes = LockResource(loaded);
    DWORD size = SizeofResource(NULL, resource);
    if (!bytes || !size) return FALSE;

    uint64_t hash = UINT64_C(14695981039346656037);
    for (DWORD i = 0; i < size; i++) {
        hash ^= bytes[i];
        hash *= UINT64_C(1099511628211);
    }

    wchar_t temporary[MAX_PATH];
    DWORD length = GetTempPathW(MAX_PATH, temporary);
    if (!length || length >= MAX_PATH) return FALSE;
    int count = swprintf(path, capacity, L"%lsAlphaROMdiE.Inject.%08lx%08lx.dll",
                         temporary, (DWORD)(hash >> 32), (DWORD)hash);
    if (count < 0 || (size_t)count >= capacity) {
        SetLastError(ERROR_INSUFFICIENT_BUFFER);
        return FALSE;
    }
    HANDLE output = CreateFileW(path, GENERIC_WRITE, 0, NULL, CREATE_NEW,
                                FILE_ATTRIBUTE_NORMAL, NULL);
    if (output == INVALID_HANDLE_VALUE) {
        if (GetLastError() != ERROR_FILE_EXISTS && GetLastError() != ERROR_ALREADY_EXISTS)
            return FALSE;
        HANDLE input = INVALID_HANDLE_VALUE;
        for (int attempt = 0; attempt < 20; attempt++) {
            input = CreateFileW(path, GENERIC_READ,
                                FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE,
                                NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
            if (input != INVALID_HANDLE_VALUE) break;
            if (GetLastError() != ERROR_SHARING_VIOLATION) return FALSE;
            Sleep(50);
        }
        if (input == INVALID_HANDLE_VALUE) return FALSE;
        BOOL okay = GetFileSize(input, NULL) == size;
        BYTE buffer[4096];
        for (DWORD offset = 0; okay && offset < size; offset += sizeof(buffer)) {
            DWORD expected = size - offset < sizeof(buffer) ? size - offset : sizeof(buffer);
            DWORD received = 0;
            okay = ReadFile(input, buffer, expected, &received, NULL) &&
                   received == expected && memcmp(buffer, bytes + offset, expected) == 0;
        }
        CloseHandle(input);
        if (!okay) SetLastError(ERROR_INVALID_DATA);
        return okay;
    }
    DWORD written = 0;
    BOOL okay = WriteFile(output, bytes, size, &written, NULL) && written == size;
    CloseHandle(output);
    if (!okay) DeleteFileW(path);
    return okay;
}

int wmain(int argc, wchar_t **argv) {
    if (argc > 1 && wcscmp(argv[1], L"--patch") == 0) {
        if (argc < 3 || argc > 4) {
            fwprintf(stderr, L"Usage: AlphaROMdiE-Rebuilt.exe --patch GAME.exe [OUTPUT.exe]\n");
            return 2;
        }
        wchar_t helper[MAX_PATH], output[MAX_PATH];
        if (!cache_helper(helper, MAX_PATH)) return fail(L"cache embedded helper");
        if (!patch_game(argv[2], argc == 4 ? argv[3] : NULL, helper, output))
            return fail(L"patch game EXE");
        wprintf(L"Created same-process game EXE: %ls\n", output);
        return 0;
    }
    if (argc > 1 && wcscmp(argv[1], L"--generate") == 0) {
        if (argc < 3 || argc > 4) {
            fwprintf(stderr, L"Usage: AlphaROMdiE-Rebuilt.exe --generate GAME.exe [OUTPUT.exe]\n");
            return 2;
        }
        wchar_t self[MAX_PATH];
        DWORD self_length = GetModuleFileNameW(NULL, self, MAX_PATH);
        if (!self_length || self_length >= MAX_PATH) return fail(L"GetModuleFileNameW");
        return generate_launcher(self, argv[2], argc == 4 ? argv[3] : NULL);
    }
    BOOL debug_mode = argc > 1 && wcscmp(argv[1], L"--debug") == 0;
    BOOL wait_for_game = debug_mode || (argc > 1 && wcscmp(argv[1], L"--wait") == 0);
    int target_index = wait_for_game ? 2 : 1;
    wchar_t helper[MAX_PATH], target[MAX_PATH], directory[MAX_PATH];
    wchar_t launcher_directory[MAX_PATH], configured_target[MAX_PATH];
    DWORD length = GetModuleFileNameW(NULL, helper, MAX_PATH);
    if (!length || length >= MAX_PATH) return fail(L"GetModuleFileNameW");
    wchar_t *slash = wcsrchr(helper, L'\\');
    if (!slash) return 2;
    wcscpy(launcher_directory, helper);
    launcher_directory[slash - helper] = L'\0';
    const wchar_t *requested_target;
    int game_args_start;
    int embedded = read_embedded_target(helper, configured_target);
    if (embedded < 0) return fail(L"read generated target");
    if (embedded) {
        SetCurrentDirectoryW(launcher_directory);
        requested_target = configured_target;
        game_args_start = target_index;
    } else if (argc <= target_index) {
            wcscpy(slash + 1, L"AlphaROMdiE-Rebuilt.ini");
            if (!GetPrivateProfileStringW(L"launcher", L"Target", L"", configured_target,
                                         MAX_PATH, helper)) {
                fwprintf(stderr, L"Usage: AlphaROMdiE-Rebuilt.exe [--debug|--wait] GAME.exe [game arguments]\n"
                                 L"Use --generate GAME.exe to make a directly launchable copy.\n");
                return 2;
            }
        SetCurrentDirectoryW(launcher_directory);
        requested_target = configured_target;
        game_args_start = target_index;
    } else {
        requested_target = argv[target_index];
        game_args_start = target_index + 1;
    }
    length = GetFullPathNameW(requested_target, MAX_PATH, target, NULL);
    if (!length || length >= MAX_PATH) return fail(L"GetFullPathNameW");
    wcscpy(directory, target);
    slash = wcsrchr(directory, L'\\');
    if (!slash) return 2;
    *slash = L'\0';

    if (!cache_helper(helper, MAX_PATH)) return fail(L"cache embedded helper");

    /* Build a quoted command line. This also works when the game lives in a path with spaces. */
    size_t capacity = 32768;
    wchar_t *command = HeapAlloc(GetProcessHeap(), HEAP_ZERO_MEMORY, capacity * sizeof(wchar_t));
    if (!command) return fail(L"HeapAlloc");
    wcscat(command, L"\""); wcscat(command, target); wcscat(command, L"\"");
    for (int i = game_args_start; i < argc; i++) {
        if (wcslen(command) + wcslen(argv[i]) + 5 >= capacity) {
            HeapFree(GetProcessHeap(), 0, command);
            return 2;
        }
        wcscat(command, L" \""); wcscat(command, argv[i]); wcscat(command, L"\"");
    }
    STARTUPINFOW startup = {0};
    PROCESS_INFORMATION child = {0};
    startup.cb = sizeof(startup);
    if (!SetEnvironmentVariableW(L"ALPHAROMDIE_DEBUG", debug_mode ? L"1" : NULL)) {
        HeapFree(GetProcessHeap(), 0, command);
        return fail(L"SetEnvironmentVariableW");
    }
    if (!CreateProcessW(target, command, NULL, NULL, FALSE, CREATE_SUSPENDED,
                        NULL, directory, &startup, &child)) {
        int result = fail(L"CreateProcessW");
        HeapFree(GetProcessHeap(), 0, command);
        return result;
    }
    HeapFree(GetProcessHeap(), 0, command);

    HMODULE local = LoadLibraryExW(helper, NULL, DONT_RESOLVE_DLL_REFERENCES);
    if (!local) { fail(L"LoadLibraryExW(helper)"); goto child_fail; }
    FARPROC init = GetProcAddress(local, "Init");
    if (!init) { fail(L"GetProcAddress(Init)"); FreeLibrary(local); goto child_fail; }
    DWORD init_rva = (DWORD)((BYTE *)init - (BYTE *)local);
    FreeLibrary(local);
    SIZE_T bytes = (wcslen(helper) + 1) * sizeof(wchar_t);
    void *remote_path = VirtualAllocEx(child.hProcess, NULL, bytes, MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
    if (!remote_path) { fail(L"VirtualAllocEx"); goto child_fail; }
    if (!WriteProcessMemory(child.hProcess, remote_path, helper, bytes, NULL)) {
        fail(L"WriteProcessMemory"); goto child_fail;
    }
    HMODULE kernel = GetModuleHandleW(L"kernel32.dll");
    DWORD remote_module = 0;
    if (!wait_remote(child.hProcess,
                     (LPTHREAD_START_ROUTINE)GetProcAddress(kernel, "LoadLibraryW"),
                     remote_path, &remote_module) || !remote_module) {
        fail(L"remote LoadLibraryW"); goto child_fail;
    }
    VirtualFreeEx(child.hProcess, remote_path, 0, MEM_RELEASE);
    DWORD init_result = 0;
    if (!wait_remote(child.hProcess,
                     (LPTHREAD_START_ROUTINE)(remote_module + init_rva), NULL, &init_result) || !init_result) {
        fail(L"remote Init"); goto child_fail;
    }
    if (debug_mode)
        wprintf(L"AlphaROMdiE rebuild: initialized game process %lu\n", child.dwProcessId);
    if (ResumeThread(child.hThread) == (DWORD)-1) {
        fail(L"ResumeThread"); goto child_fail;
    }
    if (wait_for_game) {
        WaitForSingleObject(child.hProcess, INFINITE);
        DWORD exit_code = 0;
        GetExitCodeProcess(child.hProcess, &exit_code);
        wprintf(L"AlphaROMdiE rebuild: game exit code %lu (0x%08lx)\n", exit_code, exit_code);
    }
    CloseHandle(child.hThread);
    CloseHandle(child.hProcess);
    return 0;
child_fail:
    TerminateProcess(child.hProcess, 1);
    CloseHandle(child.hThread);
    CloseHandle(child.hProcess);
    return 1;
}
