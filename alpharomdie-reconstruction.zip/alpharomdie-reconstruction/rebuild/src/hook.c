#include "hook.h"
#include "decoder_tables.h"
#include <stdint.h>
#include <string.h>
int hook_error_code;

int x86_instruction_length(const BYTE *code) {
    const BYTE *p = code;
    uint32_t flags = 0;
    BYTE op;
    for (;;) {
        op = *p++;
        flags |= primary_flags[op];
        if (flags & 0x2000) flags = (*p & 0x38) == 0 ? 0x1800 : 0x800;
        if (flags & 0x4000) { op = *p++; flags = extended_flags[op]; }
        if (flags == UINT32_MAX) return -1;
        if (!(flags & 1)) break;
        flags &= ~1u;
    }
    if (flags & 0x1000) flags |= (op & 1) ? 8 : 16;
    if (flags & 0x800) {
        BYTE modrm = *p++;
        BYTE mod = modrm & 0xc0, rm = modrm & 7;
        if (mod != 0xc0) {
            if (!(flags & 4)) {
                if (mod == 0x40) flags |= 0x100;
                if (mod == 0x80) flags |= 0x400;
                if (rm == 4) rm = *p++ & 7;
                if (rm == 5 && mod == 0) flags |= 0x400;
            } else {
                if (mod == 0 && rm == 6) flags |= 0x200;
                if (mod == 0x40) flags |= 0x100;
                if (mod == 0x80) flags |= 0x200;
            }
        }
    }
    if (flags & 0x80) flags |= (flags & 4) ? 0x200 : 0x400;
    if (flags & 8) flags |= (flags & 2) ? 0x20 : 0x40;
    if (flags & 0x100) p++;
    if (flags & 0x200) p += 2;
    if (flags & 0x400) p += 4;
    if (flags & 0x10) p++;
    if (flags & 0x20) p += 2;
    if (flags & 0x40) p += 4;
    return (int)(p - code);
}

static BYTE *follow_jump(BYTE *p) {
    for (int i = 0; i < 8; i++) {
        if (p[0] == 0xe9) p = p + 5 + *(int32_t *)(p + 1);
        else if (p[0] == 0xeb) p = p + 2 + (int8_t)p[1];
        else if (p[0] == 0xff && p[1] == 0x25) p = *(BYTE **)(uintptr_t)*(uint32_t *)(p + 2);
        else break;
    }
    return p;
}

BOOL install_hook(Hook *h, FARPROC address, const void *callback) {
    hook_error_code = 0;
    if (!h || !address || !callback) { hook_error_code = 1; return FALSE; }
    memset(h, 0, sizeof(*h));
    h->target = follow_jump((BYTE *)address);
    while (h->length < 5) {
        int n = x86_instruction_length(h->target + h->length);
        if (n < 1 || n > 15 || h->length + n > sizeof(h->original)) {
            hook_error_code = 2; return FALSE;
        }
        /* Relative branches in the copied prologue need dedicated relocation. */
        BYTE op = h->target[h->length];
        if (op == 0xe8 || op == 0xe9 || op == 0xeb || (op >= 0x70 && op <= 0x7f) ||
            (op == 0x0f && (h->target[h->length + 1] & 0xf0) == 0x80)) {
            hook_error_code = 3; return FALSE;
        }
        h->length += (unsigned)n;
    }
    memcpy(h->original, h->target, h->length);
    h->trampoline = VirtualAlloc(NULL, h->length + 5, MEM_COMMIT | MEM_RESERVE, PAGE_EXECUTE_READWRITE);
    h->dispatch = VirtualAlloc(NULL, 19, MEM_COMMIT | MEM_RESERVE, PAGE_EXECUTE_READWRITE);
    if (!h->trampoline || !h->dispatch) goto fail;
    memcpy(h->trampoline, h->original, h->length);
    h->trampoline[h->length] = 0xe9;
    *(int32_t *)(h->trampoline + h->length + 1) =
        (int32_t)(h->target + h->length - (h->trampoline + h->length + 5));

    /* [ret,args] -> [ret,caller,trampoline,args]. No registers/flags are changed. */
    BYTE *d = h->dispatch;
    d[0] = 0xff; d[1] = 0x34; d[2] = 0x24; /* push [esp] */
    d[3] = 0xff; d[4] = 0x34; d[5] = 0x24; /* push [esp] */
    d[6] = 0xc7; d[7] = 0x44; d[8] = 0x24; d[9] = 0x08; /* mov [esp+8],imm32 */
    *(uint32_t *)(d + 10) = (uint32_t)(uintptr_t)h->trampoline;
    d[14] = 0xe9;
    *(int32_t *)(d + 15) = (int32_t)((BYTE *)callback - (d + 19));
    if (!VirtualProtect(h->target, h->length, PAGE_EXECUTE_READWRITE, &h->old_protection)) goto fail;
    h->target[0] = 0xe9;
    *(int32_t *)(h->target + 1) = (int32_t)(d - (h->target + 5));
    FlushInstructionCache(GetCurrentProcess(), h->target, h->length);
    DWORD ignored;
    VirtualProtect(h->target, h->length, h->old_protection, &ignored);
    return TRUE;
fail:
    hook_error_code = 4;
    if (h->trampoline) VirtualFree(h->trampoline, 0, MEM_RELEASE);
    if (h->dispatch) VirtualFree(h->dispatch, 0, MEM_RELEASE);
    memset(h, 0, sizeof(*h));
    return FALSE;
}

BOOL remove_hook(Hook *h) {
    if (!h || !h->target) return FALSE;
    DWORD old, ignored;
    if (!VirtualProtect(h->target, h->length, PAGE_EXECUTE_READWRITE, &old)) return FALSE;
    memcpy(h->target, h->original, h->length);
    FlushInstructionCache(GetCurrentProcess(), h->target, h->length);
    VirtualProtect(h->target, h->length, old, &ignored);
    VirtualFree(h->trampoline, 0, MEM_RELEASE);
    VirtualFree(h->dispatch, 0, MEM_RELEASE);
    memset(h, 0, sizeof(*h));
    return TRUE;
}
