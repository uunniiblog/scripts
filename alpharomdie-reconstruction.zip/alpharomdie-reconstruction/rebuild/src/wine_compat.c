/*
 * Built-in AlphaROMdiE Wine compatibility fix (32-bit).
 * SPDX-License-Identifier: MIT
 *
 * Some old protected executables rewrite imported API machine code using an
 * instruction decoder that does not understand SSE2 opcodes such as 0F D6 and
 * 0F 6C. Modern Wine USER32 and KERNEL32 pointer probes use these instructions.
 * The rewriter splits them
 * and inserts junk inside the instruction, producing an invalid code stream.
 *
 * Redirect executable USER32 exports and KERNEL32 IsBadReadPtr/IsBadWritePtr
 * through six-byte forwarding stubs:
 *     push original_address
 *     ret
 * The old rewriter can copy this sequence; Wine's implementation then executes
 * at its original address. No API signature or return value is changed.
 *
 * BGI's static C++ runtime calls these pointer probes when copying a caught
 * exception. On GE11-7 the protected copy of IsBadReadPtr splits the MOVQ
 * (66 0F D6) used to initialize Wine's SEH frame, leading to random faults
 * and sometimes a secondary unwind/stack-overflow failure. Forwarding keeps
 * both the probe and its exception handler in Wine's original code.
 *
 * This is process-local. System DLLs on disk and game files are never patched.
 * Stubs must remain allocated until process exit, even if this DLL is unloaded.
 */
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stdio.h>
#include <string.h>
#include "wine_compat.h"

#ifdef _WIN64
#error Build this plugin for i686, not x86_64.
#endif

static FILE *compat_log;

static void report(const char *message, DWORD value)
{
    char line[256];
    int size = snprintf(line, sizeof(line), "WineCompat: %s (%lu)\r\n",
                        message, (unsigned long)value);
    if (size <= 0 || size >= (int)sizeof(line)) return;
    OutputDebugStringA(line);
    if (compat_log) { fputs(line, compat_log); fflush(compat_log); }
}

static BOOL wrap_exports(const char *module, BOOL pointer_probes)
{
    BYTE *base = (BYTE *)GetModuleHandleA(module);
    if (!base) base = (BYTE *)LoadLibraryA(module);
    if (!base) return FALSE;
    IMAGE_DOS_HEADER *dos = (IMAGE_DOS_HEADER *)base;
    IMAGE_NT_HEADERS32 *nt = (IMAGE_NT_HEADERS32 *)(base + dos->e_lfanew);
    if (dos->e_magic != IMAGE_DOS_SIGNATURE ||
        nt->Signature != IMAGE_NT_SIGNATURE ||
        nt->OptionalHeader.Magic != IMAGE_NT_OPTIONAL_HDR32_MAGIC) return FALSE;

    IMAGE_DATA_DIRECTORY dir = nt->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_EXPORT];
    if (!dir.VirtualAddress || !dir.Size) return FALSE;
    IMAGE_EXPORT_DIRECTORY *exports = (IMAGE_EXPORT_DIRECTORY *)(base + dir.VirtualAddress);
    DWORD count = exports->NumberOfFunctions;
    if (!count || count > 65536) return FALSE;
    DWORD *table = (DWORD *)(base + exports->AddressOfFunctions);
    DWORD *replacement = HeapAlloc(GetProcessHeap(), 0, count * sizeof(DWORD));
    if (!replacement) return FALSE;
    BYTE *stubs = VirtualAlloc(NULL, count * 8, MEM_RESERVE | MEM_COMMIT, PAGE_READWRITE);
    if (!stubs) {
        HeapFree(GetProcessHeap(), 0, replacement);
        return FALSE;
    }

    DWORD wrapped = 0;
    DWORD *names = (DWORD *)(base + exports->AddressOfNames);
    WORD *ordinals = (WORD *)(base + exports->AddressOfNameOrdinals);
    for (DWORD i = 0; i < count; ++i) {
        DWORD rva = table[i];
        replacement[i] = rva;
        if (pointer_probes) {
            BOOL selected = FALSE;
            for (DWORD n = 0; n < exports->NumberOfNames; ++n) {
                if (ordinals[n] == i &&
                    (!strcmp((char *)base + names[n], "IsBadReadPtr") ||
                     !strcmp((char *)base + names[n], "IsBadWritePtr"))) {
                    selected = TRUE;
                    break;
                }
            }
            if (!selected) continue;
        }
        /* Leave missing exports, forwarder strings and exported data alone. */
        if (!rva || rva >= nt->OptionalHeader.SizeOfImage ||
            (rva >= dir.VirtualAddress && rva - dir.VirtualAddress < dir.Size)) continue;
        MEMORY_BASIC_INFORMATION info;
        if (!VirtualQuery(base + rva, &info, sizeof(info)) ||
            info.State != MEM_COMMIT || !(info.Protect & 0xf0) ||
            (info.Protect & PAGE_GUARD)) continue;

        /* Preserve address equality between aliases of the same function. */
        DWORD j;
        for (j = 0; j < i; ++j)
            if (table[j] == rva && replacement[j] != rva) break;
        if (j < i) {
            replacement[i] = replacement[j];
        } else {
            BYTE *stub = stubs + i * 8;
            DWORD target = (DWORD)(ULONG_PTR)(base + rva);
            stub[0] = 0x68; /* push imm32 */
            CopyMemory(stub + 1, &target, sizeof(target));
            stub[5] = 0xc3; /* ret */
            stub[6] = stub[7] = 0x90;
            /* PE32 address arithmetic intentionally wraps modulo 2^32. */
            replacement[i] = (DWORD)(ULONG_PTR)stub - (DWORD)(ULONG_PTR)base;
        }
        ++wrapped;
    }

    DWORD old;
    if (!VirtualProtect(stubs, count * 8, PAGE_EXECUTE_READ, &old)) goto failure;
    FlushInstructionCache(GetCurrentProcess(), stubs, count * 8);
    if (!VirtualProtect(table, count * sizeof(DWORD), PAGE_READWRITE, &old)) goto failure;
    CopyMemory(table, replacement, count * sizeof(DWORD));
    DWORD ignored;
    if (!VirtualProtect(table, count * sizeof(DWORD), old, &ignored))
        report("could not restore export-table page protection", GetLastError());
    HeapFree(GetProcessHeap(), 0, replacement);
    report(pointer_probes ? "installed KERNEL32 pointer-probe forwarding exports" :
           "installed USER32 forwarding exports", wrapped);
    return TRUE;

failure:
    VirtualFree(stubs, 0, MEM_RELEASE);
    HeapFree(GetProcessHeap(), 0, replacement);
    return FALSE;
}

BOOL install_wine_compat(FILE *logfile)
{
    compat_log = logfile;
    HMODULE ntdll = GetModuleHandleA("ntdll.dll");
    if (!ntdll || !GetProcAddress(ntdll, "wine_get_version")) {
        if (logfile) { fputs("WineCompat: native Windows, fix skipped\n", logfile); fflush(logfile); }
        return TRUE;
    }
    if (!wrap_exports("user32.dll", FALSE)) {
        report("failed to install USER32 forwarding exports", GetLastError());
        return FALSE;
    }
    if (!wrap_exports("kernel32.dll", TRUE)) {
        report("failed to install KERNEL32 pointer-probe forwarding exports", GetLastError());
        return FALSE;
    }
    return TRUE;
}
