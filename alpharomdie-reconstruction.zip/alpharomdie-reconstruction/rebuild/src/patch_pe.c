#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <wchar.h>
#include "patch_pe.h"

static DWORD align_up(DWORD value, DWORD alignment) {
    return (value + alignment - 1) / alignment * alignment;
}

static BOOL read_entire_file(const wchar_t *path, BYTE **bytes, DWORD *length) {
    HANDLE file = CreateFileW(path, GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_DELETE,
                              NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
    if (file == INVALID_HANDLE_VALUE) return FALSE;
    LARGE_INTEGER size;
    BOOL okay = GetFileSizeEx(file, &size) && size.QuadPart > 0 && size.QuadPart <= 0x40000000;
    if (!okay) { CloseHandle(file); SetLastError(ERROR_FILE_TOO_LARGE); return FALSE; }
    BYTE *data = HeapAlloc(GetProcessHeap(), 0, (SIZE_T)size.QuadPart);
    if (!data) { CloseHandle(file); return FALSE; }
    DWORD received = 0;
    okay = ReadFile(file, data, (DWORD)size.QuadPart, &received, NULL) &&
           received == (DWORD)size.QuadPart;
    CloseHandle(file);
    if (!okay) { HeapFree(GetProcessHeap(), 0, data); return FALSE; }
    *bytes = data;
    *length = received;
    return TRUE;
}

static BOOL same_file_contents(const wchar_t *first, const wchar_t *second) {
    BYTE *left = NULL, *right = NULL;
    DWORD left_size = 0, right_size = 0;
    BOOL okay = read_entire_file(first, &left, &left_size);
    if (okay) okay = read_entire_file(second, &right, &right_size);
    if (okay) okay = left_size == right_size && memcmp(left, right, left_size) == 0;
    if (right) HeapFree(GetProcessHeap(), 0, right);
    if (left) HeapFree(GetProcessHeap(), 0, left);
    if (!okay) SetLastError(ERROR_INVALID_DATA);
    return okay;
}

static DWORD rva_offset(IMAGE_NT_HEADERS32 *nt, DWORD rva, DWORD file_size) {
    IMAGE_SECTION_HEADER *sections = IMAGE_FIRST_SECTION(nt);
    for (WORD i = 0; i < nt->FileHeader.NumberOfSections; i++) {
        DWORD virtual_size = sections[i].Misc.VirtualSize > sections[i].SizeOfRawData ?
                             sections[i].Misc.VirtualSize : sections[i].SizeOfRawData;
        if (rva >= sections[i].VirtualAddress &&
            rva - sections[i].VirtualAddress < virtual_size) {
            DWORD offset = sections[i].PointerToRawData + rva - sections[i].VirtualAddress;
            if (offset < file_size) return offset;
        }
    }
    return 0;
}

BOOL patch_game(const wchar_t *game_argument, const wchar_t *output_argument,
                const wchar_t *cached_helper, wchar_t *created_output) {
    wchar_t game[MAX_PATH], output[MAX_PATH], local_helper[MAX_PATH];
    DWORD path_length = GetFullPathNameW(game_argument, MAX_PATH, game, NULL);
    if (!path_length || path_length >= MAX_PATH) return FALSE;
    wchar_t *slash = wcsrchr(game, L'\\');
    if (!slash || !slash[1]) { SetLastError(ERROR_INVALID_NAME); return FALSE; }
    if (output_argument) {
        path_length = GetFullPathNameW(output_argument, MAX_PATH, output, NULL);
        if (!path_length || path_length >= MAX_PATH) return FALSE;
        wchar_t *output_slash = wcsrchr(output, L'\\');
        if (!output_slash || output_slash - output != slash - game ||
            _wcsnicmp(output, game, slash - game) != 0) {
            SetLastError(ERROR_INVALID_NAME); return FALSE;
        }
    } else {
        wcscpy(output, game);
        wchar_t *dot = wcsrchr(output, L'.');
        if (!dot || _wcsicmp(dot, L".exe") != 0) {
            SetLastError(ERROR_INVALID_NAME); return FALSE;
        }
        int count = swprintf(dot, MAX_PATH - (dot - output), L".AlphaROMdiE.native.exe");
        if (count < 0 || count >= MAX_PATH - (dot - output)) {
            SetLastError(ERROR_INSUFFICIENT_BUFFER); return FALSE;
        }
    }
    if (_wcsicmp(game, output) == 0 || GetFileAttributesW(output) != INVALID_FILE_ATTRIBUTES) {
        SetLastError(ERROR_FILE_EXISTS); return FALSE;
    }
    const wchar_t *helper_name = wcsrchr(cached_helper, L'\\');
    if (!helper_name) { SetLastError(ERROR_INVALID_NAME); return FALSE; }
    helper_name++;
    int helper_count = swprintf(local_helper, MAX_PATH, L"%.*ls\\%ls",
                                (int)(slash - game), game, helper_name);
    if (helper_count < 0 || helper_count >= MAX_PATH) {
        SetLastError(ERROR_INSUFFICIENT_BUFFER); return FALSE;
    }

    BYTE *original = NULL;
    DWORD original_size = 0;
    if (!read_entire_file(game, &original, &original_size)) return FALSE;
    BOOL okay = FALSE;
    BYTE *patched = NULL;
    if (original_size < sizeof(IMAGE_DOS_HEADER)) goto invalid;
    IMAGE_DOS_HEADER *dos = (IMAGE_DOS_HEADER *)original;
    if (dos->e_magic != IMAGE_DOS_SIGNATURE || dos->e_lfanew <= 0 ||
        (DWORD)dos->e_lfanew > original_size - sizeof(IMAGE_NT_HEADERS32)) goto invalid;
    IMAGE_NT_HEADERS32 *nt = (IMAGE_NT_HEADERS32 *)(original + dos->e_lfanew);
    if (nt->Signature != IMAGE_NT_SIGNATURE ||
        nt->FileHeader.Machine != IMAGE_FILE_MACHINE_I386 ||
        nt->OptionalHeader.Magic != IMAGE_NT_OPTIONAL_HDR32_MAGIC ||
        nt->FileHeader.NumberOfSections == 0 || nt->FileHeader.NumberOfSections >= 96) goto invalid;
    IMAGE_SECTION_HEADER *sections = IMAGE_FIRST_SECTION(nt);
    DWORD section_header_offset = (BYTE *)sections - original;
    DWORD section_count = nt->FileHeader.NumberOfSections;
    if (section_header_offset > original_size ||
        section_count * sizeof(IMAGE_SECTION_HEADER) > original_size - section_header_offset ||
        (section_count + 1) * sizeof(IMAGE_SECTION_HEADER) > original_size - section_header_offset)
        goto invalid;
    DWORD first_raw = original_size;
    for (DWORD i = 0; i < section_count; i++)
        if (sections[i].PointerToRawData && sections[i].PointerToRawData < first_raw)
            first_raw = sections[i].PointerToRawData;
    if (section_header_offset + (section_count + 1) * sizeof(IMAGE_SECTION_HEADER) > first_raw ||
        section_header_offset + (section_count + 1) * sizeof(IMAGE_SECTION_HEADER) >
        nt->OptionalHeader.SizeOfHeaders) goto invalid;
    DWORD section_alignment = nt->OptionalHeader.SectionAlignment;
    DWORD file_alignment = nt->OptionalHeader.FileAlignment;
    if (!section_alignment || !file_alignment || section_alignment > 0x100000 ||
        file_alignment > 0x100000 ||
        nt->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_SECURITY].Size) goto invalid;
    DWORD original_entry = nt->OptionalHeader.AddressOfEntryPoint;
    DWORD new_virtual = nt->OptionalHeader.SizeOfImage;
    for (DWORD i = 0; i < section_count; i++) {
        DWORD extent = sections[i].Misc.VirtualSize > sections[i].SizeOfRawData ?
                       sections[i].Misc.VirtualSize : sections[i].SizeOfRawData;
        DWORD end = sections[i].VirtualAddress + extent;
        if (end > new_virtual) new_virtual = end;
    }
    new_virtual = align_up(new_virtual, section_alignment);
    DWORD new_raw = align_up(original_size, file_alignment);

    BYTE payload[8192] = {0};
    DWORD position = 32;
    DWORD descriptor_rva = new_virtual + position;
    IMAGE_DATA_DIRECTORY *imports = &nt->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_IMPORT];
    if (imports->VirtualAddress) {
        DWORD offset = rva_offset(nt, imports->VirtualAddress, original_size);
        if (!offset) goto invalid;
        for (DWORD i = 0; i < 256; i++) {
            if (offset + sizeof(IMAGE_IMPORT_DESCRIPTOR) > original_size ||
                position + sizeof(IMAGE_IMPORT_DESCRIPTOR) + 512 > sizeof(payload)) goto invalid;
            IMAGE_IMPORT_DESCRIPTOR *descriptor = (IMAGE_IMPORT_DESCRIPTOR *)(original + offset);
            if (!descriptor->OriginalFirstThunk && !descriptor->FirstThunk && !descriptor->Name)
                break;
            memcpy(payload + position, descriptor, sizeof(*descriptor));
            position += sizeof(*descriptor);
            offset += sizeof(*descriptor);
            if (i == 255) goto invalid;
        }
    }
    DWORD new_descriptor = position;
    position += 2 * sizeof(IMAGE_IMPORT_DESCRIPTOR);
    DWORD lookup_rva = new_virtual + position;
    position += 8;
    DWORD address_rva = new_virtual + position;
    position += 8;
    DWORD dll_name_rva = new_virtual + position;
    size_t name_bytes = strlen("AlphaROMdiE.Inject.") + 16 + strlen(".dll") + 1;
    char narrow_helper[80];
    size_t helper_length = wcslen(helper_name);
    if (helper_length >= sizeof(narrow_helper) || helper_length > name_bytes) goto invalid;
    for (size_t i = 0; i <= helper_length; i++) {
        if (helper_name[i] > 0x7f) goto invalid;
        narrow_helper[i] = (char)helper_name[i];
    }
    memcpy(payload + position, narrow_helper, helper_length + 1);
    position += (DWORD)helper_length + 1;
    position = align_up(position, 2);
    DWORD hint_name_rva = new_virtual + position;
    memcpy(payload + position, "\0\0Init\0", 7);
    position += 7;
    IMAGE_IMPORT_DESCRIPTOR *extra = (IMAGE_IMPORT_DESCRIPTOR *)(payload + new_descriptor);
    extra->OriginalFirstThunk = lookup_rva;
    extra->Name = dll_name_rva;
    extra->FirstThunk = address_rva;
    memcpy(payload + lookup_rva - new_virtual, &hint_name_rva, 4);
    memcpy(payload + address_rva - new_virtual, &hint_name_rva, 4);

    static const BYTE stub[31] = {
        0x9c, 0x60, 0xe8, 0, 0, 0, 0, 0x5b, 0x81, 0xeb, 0, 0, 0, 0,
        0x8b, 0x83, 0, 0, 0, 0, 0x6a, 0, 0xff, 0xd0, 0x61, 0x9d,
        0xe9, 0, 0, 0, 0
    };
    memcpy(payload, stub, sizeof(stub));
    DWORD base_adjust = new_virtual + 7;
    DWORD relative_entry = original_entry - (new_virtual + sizeof(stub));
    memcpy(payload + 10, &base_adjust, 4);
    memcpy(payload + 16, &address_rva, 4);
    memcpy(payload + 27, &relative_entry, 4);
    DWORD raw_size = align_up(position, file_alignment);
    if (raw_size > sizeof(payload) || new_raw > 0x40000000 ||
        raw_size > 0x40000000 - new_raw) goto invalid;
    DWORD output_size = new_raw + raw_size;
    patched = HeapAlloc(GetProcessHeap(), HEAP_ZERO_MEMORY, output_size);
    if (!patched) goto done;
    memcpy(patched, original, original_size);
    memcpy(patched + new_raw, payload, position);
    IMAGE_NT_HEADERS32 *new_nt = (IMAGE_NT_HEADERS32 *)(patched + dos->e_lfanew);
    IMAGE_SECTION_HEADER *new_sections = IMAGE_FIRST_SECTION(new_nt);
    IMAGE_SECTION_HEADER *added = &new_sections[section_count];
    memset(added, 0, sizeof(*added));
    memcpy(added->Name, ".ardie", 6);
    added->Misc.VirtualSize = position;
    added->VirtualAddress = new_virtual;
    added->SizeOfRawData = raw_size;
    added->PointerToRawData = new_raw;
    added->Characteristics = IMAGE_SCN_CNT_CODE | IMAGE_SCN_CNT_INITIALIZED_DATA |
                             IMAGE_SCN_MEM_EXECUTE | IMAGE_SCN_MEM_READ | IMAGE_SCN_MEM_WRITE;
    new_nt->FileHeader.NumberOfSections++;
    new_nt->OptionalHeader.AddressOfEntryPoint = new_virtual;
    new_nt->OptionalHeader.SizeOfImage = align_up(new_virtual + position, section_alignment);
    new_nt->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_IMPORT].VirtualAddress = descriptor_rva;
    new_nt->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_IMPORT].Size =
        new_virtual + new_descriptor - descriptor_rva + 2 * sizeof(IMAGE_IMPORT_DESCRIPTOR);
    new_nt->OptionalHeader.CheckSum = 0;

    if (!CopyFileW(cached_helper, local_helper, TRUE)) {
        DWORD error = GetLastError();
        if ((error != ERROR_FILE_EXISTS && error != ERROR_ALREADY_EXISTS) ||
            !same_file_contents(cached_helper, local_helper)) goto done;
    }
    HANDLE output_file = CreateFileW(output, GENERIC_WRITE, 0, NULL, CREATE_NEW,
                                     FILE_ATTRIBUTE_NORMAL, NULL);
    if (output_file == INVALID_HANDLE_VALUE) goto done;
    DWORD written = 0;
    okay = WriteFile(output_file, patched, output_size, &written, NULL) && written == output_size;
    CloseHandle(output_file);
    if (!okay) DeleteFileW(output);
    if (okay) wcscpy(created_output, output);
    goto done;
invalid:
    SetLastError(ERROR_BAD_EXE_FORMAT);
done:
    if (patched) HeapFree(GetProcessHeap(), 0, patched);
    HeapFree(GetProcessHeap(), 0, original);
    return okay;
}
