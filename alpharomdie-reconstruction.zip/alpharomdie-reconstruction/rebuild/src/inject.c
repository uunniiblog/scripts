#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stdint.h>
#include <stdio.h>
#include <wchar.h>
#include "hook.h"
#include "locale.h"
#include "engine.h"
#include "wine_compat.h"

typedef DWORD (WINAPI *DriveFn)(LPCSTR);
typedef BOOL (WINAPI *UserNameFn)(LPSTR, LPDWORD);

static Hook protection_hook;
static BYTE *game_code, *game_code_end, *breakpoint_site;
static BYTE breakpoint_original;
static DWORD check_mode, xor_key;
static PVOID exception_handler;
static FILE *logfile;
static unsigned logged_hook_calls;
static BOOL integrated_wine_fix;

static void log_line(const char *message) {
    if (logfile) { fprintf(logfile, "%s\n", message); fflush(logfile); }
}

static BOOL writable(void *address, SIZE_T size, DWORD *old) {
    return VirtualProtect(address, size, PAGE_EXECUTE_READWRITE, old);
}

static void restore_breakpoint(void) {
    if (!breakpoint_site) return;
    DWORD old, ignored;
    if (writable(breakpoint_site, 1, &old)) {
        *breakpoint_site = breakpoint_original;
        FlushInstructionCache(GetCurrentProcess(), breakpoint_site, 1);
        VirtualProtect(breakpoint_site, 1, old, &ignored);
    }
    breakpoint_site = NULL;
}

static void patch_branch(BYTE *return_site) {
    BYTE *p = return_site, *branch = NULL;
    int32_t displacement = 0;
    for (int i = 0; i < 5 && !IsBadReadPtr(p, 15); i++) {
        if (*p == 0x0f) { branch = p; displacement = *(int32_t *)(p + 2); }
        int length = x86_instruction_length(p);
        if (length < 1 || length > 15) return;
        p += length;
        if (displacement) break;
    }
    if (!branch || !displacement) return;
    BYTE *target = p + displacement + 6;
    if (IsBadReadPtr(target, 4) || *(uint32_t *)target != 0xffffffffu) return;
    DWORD old, ignored;
    if (!writable(branch, 6, &old)) return;
    branch[0] = 0x90; branch[1] = 0xe9;
    VirtualProtect(branch, 6, old, &ignored);
    if (!writable(target, 4, &old)) return;
    *(uint32_t *)target = 1;
    VirtualProtect(target, 4, old, &ignored);
    FlushInstructionCache(GetCurrentProcess(), branch, 6);
    check_mode = 0;
    log_line("Protection branch patched");
}

static void patch_cpuid(BYTE *return_site) {
    BYTE *p = return_site;
    uint32_t *base = NULL, offset = 0;
    for (int i = 0; i < 80 && !IsBadReadPtr(p, 6); i++) {
        if (*p == 0x8b) base = *(uint32_t **)(p + 2);
        if (*p == 0x39) offset = *(uint32_t *)(p + 2);
        if (base && offset) {
            uint32_t eax, ebx, ecx, edx;
            __asm__ volatile("cpuid" : "=a"(eax), "=b"(ebx), "=c"(ecx), "=d"(edx) : "a"(1));
            DWORD old, ignored;
            if (writable((BYTE *)*base + offset, 4, &old)) {
                *(uint32_t *)((BYTE *)*base + offset) = eax ^ xor_key;
                VirtualProtect((BYTE *)*base + offset, 4, old, &ignored);
                check_mode = 0;
                log_line("CPUID check patched");
            }
            return;
        }
        int n = x86_instruction_length(p);
        if (n < 1 || n > 15) return;
        p += n;
    }
}

static LONG CALLBACK on_exception(PEXCEPTION_POINTERS e) {
    if (e->ExceptionRecord->ExceptionCode != EXCEPTION_BREAKPOINT ||
        !breakpoint_site || e->ExceptionRecord->ExceptionAddress != breakpoint_site)
        return EXCEPTION_CONTINUE_SEARCH;
    BYTE *return_site = NULL;
    if (!IsBadReadPtr((void *)e->ContextRecord->Esp, 4))
        return_site = *(BYTE **)e->ContextRecord->Esp;
    if (return_site) {
        if (check_mode == 1) patch_branch(return_site);
        else if (check_mode == 2 && xor_key) patch_cpuid(return_site);
    }
    BYTE *site = breakpoint_site;
    restore_breakpoint();
    if (e->ContextRecord->Eip == (DWORD)(uintptr_t)(site + 1))
        e->ContextRecord->Eip = (DWORD)(uintptr_t)site;
    log_line("Protection breakpoint handled");
    return EXCEPTION_CONTINUE_EXECUTION;
}

static void observe_caller(BYTE *caller) {
    if (!check_mode || breakpoint_site || caller < game_code || caller >= game_code_end) return;
    BYTE *p = caller;
    for (int i = 0; i < 80 && p < game_code_end && !IsBadReadPtr(p, 6); i++) {
        if (check_mode == 2 && !xor_key && *p == 0x35) xor_key = *(uint32_t *)(p + 1);
        if (*p == 0xcc) return;
        if (*p == 0xc3) {
            DWORD old, ignored;
            if (!exception_handler) exception_handler = AddVectoredExceptionHandler(1, on_exception);
            if (!exception_handler || !writable(p, 1, &old)) return;
            breakpoint_site = p;
            breakpoint_original = *p;
            *p = 0xcc;
            FlushInstructionCache(GetCurrentProcess(), p, 1);
            VirtualProtect(p, 1, old, &ignored);
            log_line("Protection breakpoint armed");
            return;
        }
        int n = x86_instruction_length(p);
        if (n < 1 || n > 15) return;
        p += n;
    }
}

static DWORD WINAPI on_drive(void *caller, DriveFn original, LPCSTR path) {
    if (logfile && logged_hook_calls++ < 8) {
        fprintf(logfile, "GetDriveTypeA caller=%p\n", caller); fflush(logfile);
    }
    observe_caller(caller);
    return original(path);
}

static BOOL WINAPI on_user_name(void *caller, UserNameFn original, LPSTR buffer, LPDWORD length) {
    if (logfile && logged_hook_calls++ < 8) {
        fprintf(logfile, "GetUserNameA caller=%p\n", caller); fflush(logfile);
    }
    observe_caller(caller);
    return original(buffer, length);
}

static void load_plugins(void) {
    WIN32_FIND_DATAW data;
    HANDLE scan = FindFirstFileW(L"Plugin\\*.adp", &data);
    if (scan == INVALID_HANDLE_VALUE) { log_line("No Plugin/*.adp files"); return; }
    do {
        if (integrated_wine_fix && _wcsicmp(data.cFileName, L"WineCompat.adp") == 0) {
            log_line("Plugin WineCompat.adp skipped: fix is built into helper");
            continue;
        }
        wchar_t path[MAX_PATH];
        if (swprintf(path, MAX_PATH, L"Plugin\\%ls", data.cFileName) < 0) continue;
        HMODULE plugin = LoadLibraryW(path);
        if (logfile) {
            fprintf(logfile, "Plugin %ls: %s (error %lu)\n", data.cFileName,
                    plugin ? "loaded" : "FAILED", plugin ? 0 : GetLastError());
            fflush(logfile);
        }
    } while (FindNextFileW(scan, &data));
    FindClose(scan);
}

__declspec(dllexport) DWORD WINAPI Init(void *unused) {
    (void)unused;
    wchar_t path[MAX_PATH];
    char debug_value[2];
    if (GetEnvironmentVariableA("ALPHAROMDIE_DEBUG", debug_value, sizeof(debug_value)) == 1 &&
        debug_value[0] == '1' && GetModuleFileNameW(NULL, path, MAX_PATH)) {
        wchar_t *slash = wcsrchr(path, L'\\');
        if (slash && slash - path + wcslen(L"\\AlphaROMdiE.Inject.log") < MAX_PATH) {
            wcscpy(slash, L"\\AlphaROMdiE.Inject.log");
            logfile = _wfopen(path, L"w");
        }
    }
    log_line("AlphaROMdiE rebuilt helper Init");
    if (logfile) { fprintf(logfile, "system ANSI code page=%u\n", GetACP()); fflush(logfile); }
    HMODULE game = GetModuleHandleW(NULL);
    BYTE *base = (BYTE *)game;
    IMAGE_NT_HEADERS32 *nt = (IMAGE_NT_HEADERS32 *)(base + ((IMAGE_DOS_HEADER *)base)->e_lfanew);
    IMAGE_SECTION_HEADER *section = IMAGE_FIRST_SECTION(nt);
    game_code = base + section->VirtualAddress;
    game_code_end = game_code + section->Misc.VirtualSize;
    check_mode = *(uint32_t *)((BYTE *)nt + 0xc4) == 0 ? 1 : 2;
    char override[4];
    if (GetEnvironmentVariableA("ALPHAROMDIE_CHECK_MODE", override, sizeof(override)) == 1 &&
        (override[0] == '1' || override[0] == '2')) check_mode = override[0] - '0';
    if (logfile) {
        fprintf(logfile, "mode=%lu game code=%p..%p entry=%p\n", check_mode,
                game_code, game_code_end, base + nt->OptionalHeader.AddressOfEntryPoint);
        fflush(logfile);
    }
    HMODULE api_module = LoadLibraryW(check_mode == 1 ? L"kernel32.dll" : L"advapi32.dll");
    FARPROC target = api_module ? GetProcAddress(api_module,
                                    check_mode == 1 ? "GetDriveTypeA" : "GetUserNameA") : NULL;
    if (!install_hook(&protection_hook, target,
                      check_mode == 1 ? (void *)on_drive : (void *)on_user_name)) {
        if (logfile) {
            fprintf(logfile, "hook error=%d target=%p bytes=", hook_error_code, (void *)target);
            if (target) for (int i = 0; i < 16; i++) fprintf(logfile, "%02x", ((BYTE *)target)[i]);
            fputc('\n', logfile);
        }
        log_line("FAILED: protection API hook");
        return 0;
    }
    log_line("Protection API hook installed");
    install_locale_hooks(logfile);
    install_engine_hooks(game, logfile);
    integrated_wine_fix = install_wine_compat(logfile);
    load_plugins();
    log_line("Init complete");
    return 1;
}

BOOL WINAPI DllMain(HINSTANCE instance, DWORD reason, LPVOID reserved) {
    (void)reserved;
    if (reason == DLL_PROCESS_ATTACH) DisableThreadLibraryCalls(instance);
    return TRUE;
}
