#pragma once
#include <stdio.h>
void install_locale_hooks(FILE *logfile);
