#ifndef ALPHAROMDIE_PATCH_PE_H
#define ALPHAROMDIE_PATCH_PE_H

#include <windows.h>

BOOL patch_game(const wchar_t *game_argument, const wchar_t *output_argument,
                const wchar_t *cached_helper, wchar_t *created_output);

#endif
