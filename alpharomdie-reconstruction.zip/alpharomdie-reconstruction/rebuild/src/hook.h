#pragma once
#include <windows.h>

typedef struct Hook {
    BYTE *target;
    BYTE *trampoline;
    BYTE *dispatch;
    BYTE original[16];
    unsigned length;
    DWORD old_protection;
} Hook;
extern int hook_error_code;

int x86_instruction_length(const BYTE *code);
BOOL install_hook(Hook *hook, FARPROC target, const void *callback);
BOOL remove_hook(Hook *hook);
