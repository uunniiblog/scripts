#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include "hook.h"

typedef void *(WINAPI *VirtualAllocFn)(void *, SIZE_T, DWORD, DWORD);
typedef LONG (WINAPI *ZwAllocateFn)(HANDLE, void **, ULONG, SIZE_T *, ULONG, ULONG);

static Hook virtual_alloc_hook, zw_alloc_hook;
static uint32_t *image_info;
static FILE *engine_log;

static void engine_message(const char *message) {
    if (engine_log) { fprintf(engine_log, "%s\n", message); fflush(engine_log); }
}

/* Matches the original function at RVA 0x1000: PE RVA to file offset. */
static uint32_t file_offset(IMAGE_NT_HEADERS32 *nt, uint32_t rva) {
    IMAGE_SECTION_HEADER *section = IMAGE_FIRST_SECTION(nt);
    for (int i = nt->FileHeader.NumberOfSections - 1; i >= 0; i--) {
        if (section[i].VirtualAddress <= rva)
            return section[i].PointerToRawData + rva - section[i].VirtualAddress;
    }
    return 0;
}

static void patch_loaded_image(void) {
    if (!image_info || IsBadReadPtr(image_info, 12)) return;
    char *name = (char *)(uintptr_t)image_info[0];
    BYTE *data = (BYTE *)(uintptr_t)image_info[1];
    uint32_t size = image_info[2];
    if (!name || !data || !size || IsBadReadPtr(name, MAX_PATH) || IsBadReadPtr(data, size)) return;
    size_t name_length = strlen(name);
    if ((BYTE *)(name + name_length + 5) != data || *(uint16_t *)data != IMAGE_DOS_SIGNATURE) return;
    IMAGE_DOS_HEADER *dos = (IMAGE_DOS_HEADER *)data;
    if (dos->e_lfanew < 0 || (uint32_t)dos->e_lfanew + sizeof(IMAGE_NT_HEADERS32) > size) return;
    IMAGE_NT_HEADERS32 *nt = (IMAGE_NT_HEADERS32 *)(data + dos->e_lfanew);
    if (nt->Signature != IMAGE_NT_SIGNATURE) return;
    uint32_t entry_offset = file_offset(nt, nt->OptionalHeader.AddressOfEntryPoint);
    uint32_t export_offset = file_offset(nt,
        nt->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_EXPORT].VirtualAddress);
    if (!entry_offset || !export_offset || entry_offset + 4 > size ||
        export_offset + sizeof(IMAGE_EXPORT_DIRECTORY) > size) return;
    IMAGE_EXPORT_DIRECTORY *exports = (IMAGE_EXPORT_DIRECTORY *)(data + export_offset);
    uint32_t functions_offset = file_offset(nt, exports->AddressOfFunctions);
    if (!functions_offset || functions_offset + 4 > size) return;
    DWORD old_entry, old_function, ignored;
    if (!VirtualProtect(data + entry_offset, 4, PAGE_EXECUTE_READWRITE, &old_entry)) return;
    if (!VirtualProtect(data + functions_offset, 4, PAGE_EXECUTE_READWRITE, &old_function)) {
        VirtualProtect(data + entry_offset, 4, old_entry, &ignored); return;
    }
    *(uint32_t *)(data + functions_offset) = nt->OptionalHeader.AddressOfEntryPoint + 3;
    *(uint32_t *)(data + entry_offset) = 0xc3000cc2u;
    VirtualProtect(data + functions_offset, 4, old_function, &ignored);
    VirtualProtect(data + entry_offset, 4, old_entry, &ignored);
    FlushInstructionCache(GetCurrentProcess(), data + entry_offset, 4);
    engine_message("Embedded PE loader check patched");
}

static LONG WINAPI on_zw_allocate(void *caller, ZwAllocateFn original, HANDLE process,
                                   void **base, ULONG zero_bits, SIZE_T *size,
                                   ULONG allocation_type, ULONG protection) {
    (void)caller;
    BOOL candidate = image_info && !IsBadReadPtr(image_info, 12) &&
                     image_info[0] && image_info[1] && image_info[2] &&
                     !IsBadReadPtr((void *)(uintptr_t)image_info[0], MAX_PATH) &&
                     !IsBadReadPtr((void *)(uintptr_t)image_info[1], image_info[2]);
    LONG result = original(process, base, zero_bits, size, allocation_type, protection);
    if (candidate) {
        engine_message("ZwAllocateVirtualMemory candidate observed");
        remove_hook(&zw_alloc_hook);
        patch_loaded_image();
    }
    return result;
}

static void *WINAPI on_virtual_alloc(void *caller, VirtualAllocFn original, void *address,
                                     SIZE_T size, DWORD allocation_type, DWORD protection) {
    (void)caller;
    void *result = original(address, size, allocation_type, protection);
    if (!image_info && size == 0x2a0 && result) {
        image_info = result;
        engine_message("VirtualAlloc image descriptor observed");
        remove_hook(&virtual_alloc_hook);
        HMODULE ntdll = GetModuleHandleW(L"ntdll.dll");
        FARPROC zw = ntdll ? GetProcAddress(ntdll, "ZwAllocateVirtualMemory") : NULL;
        if (install_hook(&zw_alloc_hook, zw, on_zw_allocate))
            engine_message("ZwAllocateVirtualMemory hook installed");
        else engine_message("FAILED: ZwAllocateVirtualMemory hook");
    }
    return result;
}

void install_engine_hooks(HMODULE game, FILE *logfile) {
    engine_log = logfile;
    BYTE *base = (BYTE *)game;
    IMAGE_NT_HEADERS32 *nt = (IMAGE_NT_HEADERS32 *)(base + ((IMAGE_DOS_HEADER *)base)->e_lfanew);
    IMAGE_SECTION_HEADER *sections = IMAGE_FIRST_SECTION(nt);
    int resource_index = -1, import_index = -1;
    for (int i = 0; i < nt->FileHeader.NumberOfSections; i++) {
        if (memcmp(sections[i].Name, ".rsrc", 5) == 0) resource_index = i;
        if (resource_index >= 0 && i > resource_index &&
            memcmp(sections[i].Name, ".idata", 6) == 0) { import_index = i; break; }
    }
    if (engine_log) {
        fprintf(engine_log, "engine sections: .rsrc=%d .idata=%d total=%u\n", resource_index,
                import_index, nt->FileHeader.NumberOfSections);
        fflush(engine_log);
    }
    if (import_index >= 0 && import_index < nt->FileHeader.NumberOfSections - 1) {
        HMODULE kernel = GetModuleHandleW(L"kernel32.dll");
        FARPROC virtual_alloc = kernel ? GetProcAddress(kernel, "VirtualAlloc") : NULL;
        if (install_hook(&virtual_alloc_hook, virtual_alloc, on_virtual_alloc))
            engine_message("VirtualAlloc hook installed");
        else engine_message("FAILED: VirtualAlloc hook");
    }
}
