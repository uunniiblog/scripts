#pragma once
#include <windows.h>
#include <stdio.h>

/* Forward USER32 and KERNEL32 pointer probes before the game's API rewriter runs. */
BOOL install_wine_compat(FILE *logfile);
