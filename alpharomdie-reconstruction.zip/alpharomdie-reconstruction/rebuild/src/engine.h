#pragma once
#include <windows.h>
#include <stdio.h>
void install_engine_hooks(HMODULE game, FILE *logfile);
