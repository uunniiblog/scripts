#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <ddk/ntnls.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <wchar.h>
#include "hook.h"

typedef LONG (WINAPI *UtoMFn)(char *, ULONG, ULONG *, const WCHAR *, ULONG);
typedef LONG (WINAPI *MtoUFn)(WCHAR *, ULONG, ULONG *, const char *, ULONG);
typedef LONG (WINAPI *CustomUtoMFn)(CPTABLEINFO *, char *, ULONG, ULONG *, const WCHAR *, ULONG);
typedef LONG (WINAPI *CustomMtoUFn)(CPTABLEINFO *, WCHAR *, ULONG, ULONG *, const char *, ULONG);
typedef void (WINAPI *InitCodePageFn)(USHORT *, CPTABLEINFO *);
typedef int (WINAPI *MtoWFn)(UINT, DWORD, LPCCH, int, LPWSTR, int);
typedef int (WINAPI *WtoMFn)(UINT, DWORD, LPCWCH, int, LPSTR, int, LPCCH, LPBOOL);
typedef BOOL (WINAPI *LeadFn)(BYTE);
typedef LCID (WINAPI *LcidFn)(void);
typedef LANGID (WINAPI *LangFn)(void);
typedef UINT (WINAPI *CodePageFn)(void);
typedef DWORD (WINAPI *TzFn)(LPTIME_ZONE_INFORMATION);
typedef int (WINAPI *LocaleAFn)(LCID, LCTYPE, LPSTR, int);
typedef int (WINAPI *LocaleWFn)(LCID, LCTYPE, LPWSTR, int);

static Hook locale_hooks[14];
static unsigned locale_hook_count;
static CPTABLEINFO japanese_table;
static void *nls_data;
static CustomUtoMFn rtl_custom_unicode;
static CustomMtoUFn rtl_custom_multi;

static LONG WINAPI unicode_to_multi(void *caller, UtoMFn original, char *out, ULONG max,
                                   ULONG *written, const WCHAR *input, ULONG length) {
    (void)caller;
    return rtl_custom_unicode ? rtl_custom_unicode(&japanese_table, out, max, written, input, length)
                              : original(out, max, written, input, length);
}

static LONG WINAPI multi_to_unicode(void *caller, MtoUFn original, WCHAR *out, ULONG max,
                                   ULONG *written, const char *input, ULONG length) {
    (void)caller;
    return rtl_custom_multi ? rtl_custom_multi(&japanese_table, out, max, written, input, length)
                            : original(out, max, written, input, length);
}

static int WINAPI multi_to_wide(void *caller, MtoWFn original, UINT cp, DWORD flags,
                               LPCCH input, int input_length, LPWSTR out, int out_length) {
    (void)caller;
    return original(cp == CP_ACP ? 932 : cp, flags, input, input_length, out, out_length);
}

static int WINAPI wide_to_multi(void *caller, WtoMFn original, UINT cp, DWORD flags,
                               LPCWCH input, int input_length, LPSTR out, int out_length,
                               LPCCH fallback, LPBOOL used_fallback) {
    (void)caller;
    return original(cp == CP_ACP ? 932 : cp, flags, input, input_length,
                    out, out_length, fallback, used_fallback);
}

static BOOL WINAPI is_lead_byte(void *caller, LeadFn original, BYTE value) {
    (void)caller; (void)original;
    return IsDBCSLeadByteEx(932, value);
}

static LCID WINAPI system_lcid(void *caller, LcidFn original) {
    (void)caller; (void)original; return 0x11;
}

static LANGID WINAPI system_langid(void *caller, LangFn original) {
    (void)caller; (void)original; return 0x11;
}

static UINT WINAPI gdi_codepage(void *caller, CodePageFn original) {
    (void)caller; (void)original; return 932;
}

static DWORD WINAPI timezone_info(void *caller, TzFn original, LPTIME_ZONE_INFORMATION info) {
    (void)caller;
    DWORD result = original(info);
    if (info && result != TIME_ZONE_ID_INVALID) {
        /* Japan uses UTC+9 throughout the year, with no daylight saving time. */
        info->Bias = -540;
        info->StandardBias = 0;
        info->DaylightBias = 0;
        memset(&info->StandardDate, 0, sizeof(info->StandardDate));
        memset(&info->DaylightDate, 0, sizeof(info->DaylightDate));
        wcscpy(info->StandardName, L"TOKYO");
        wcscpy(info->DaylightName, L"TOKYO");
        return TIME_ZONE_ID_UNKNOWN;
    }
    return result;
}

static int WINAPI locale_info_a(void *caller, LocaleAFn original, LCID lcid, LCTYPE type,
                                LPSTR value, int capacity) {
    (void)caller;
    int result = original(lcid, type, value, capacity);
    if (lcid == LOCALE_SYSTEM_DEFAULT && type == LOCALE_ILANGUAGE && value && capacity >= 5) {
        memcpy(value, "0411", 5); result = 5;
    }
    return result;
}

static int WINAPI locale_info_w(void *caller, LocaleWFn original, LCID lcid, LCTYPE type,
                                LPWSTR value, int capacity) {
    (void)caller;
    int result = original(lcid, type, value, capacity);
    if (lcid == LOCALE_SYSTEM_DEFAULT && type == LOCALE_ILANGUAGE && value && capacity >= 5) {
        wcscpy(value, L"0411"); result = 5;
    }
    return result;
}

static BOOL load_codepage_table(HMODULE ntdll) {
    wchar_t path[MAX_PATH];
    UINT n = GetSystemDirectoryW(path, MAX_PATH);
    if (!n || n + 11 >= MAX_PATH) return FALSE;
    wcscat(path, L"\\c_932.nls");
    HANDLE file = CreateFileW(path, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, 0, NULL);
    if (file == INVALID_HANDLE_VALUE) return FALSE;
    DWORD length = GetFileSize(file, NULL);
    if (length == INVALID_FILE_SIZE || length < 512 || length > 1024 * 1024) {
        CloseHandle(file); return FALSE;
    }
    nls_data = HeapAlloc(GetProcessHeap(), 0, length);
    DWORD read = 0;
    BOOL okay = nls_data && ReadFile(file, nls_data, length, &read, NULL) && read == length;
    CloseHandle(file);
    if (!okay) return FALSE;
    FARPROC init_address = GetProcAddress(ntdll, "RtlInitCodePageTable");
    InitCodePageFn init;
    memcpy(&init, &init_address, sizeof(init));
    rtl_custom_unicode = (CustomUtoMFn)GetProcAddress(ntdll, "RtlUnicodeToCustomCPN");
    rtl_custom_multi = (CustomMtoUFn)GetProcAddress(ntdll, "RtlCustomCPToUnicodeN");
    if (!init || !rtl_custom_unicode || !rtl_custom_multi) return FALSE;
    init((USHORT *)nls_data, &japanese_table);
    return japanese_table.CodePage == 932;
}

static void add_hook(HMODULE module, const char *name, void *handler, FILE *logfile) {
    FARPROC address = module ? GetProcAddress(module, name) : NULL;
    BOOL okay = locale_hook_count < sizeof(locale_hooks)/sizeof(locale_hooks[0]) &&
                install_hook(&locale_hooks[locale_hook_count], address, handler);
    if (logfile) {
        fprintf(logfile, "locale hook %s: %s", name, okay ? "installed" : "FAILED");
        if (!okay) fprintf(logfile, " (%d)", hook_error_code);
        fputc('\n', logfile); fflush(logfile);
    }
    if (okay) locale_hook_count++;
}

void install_locale_hooks(FILE *logfile) {
    HMODULE kernel = GetModuleHandleW(L"kernel32.dll");
    add_hook(kernel, "GetTimeZoneInformation", timezone_info, logfile);
    if (GetACP() == 932 || GetFileAttributesA("disable_conv") != INVALID_FILE_ATTRIBUTES) {
        if (logfile) { fputs("Japanese conversion hooks skipped\n", logfile); fflush(logfile); }
        return;
    }
    HMODULE ntdll = GetModuleHandleW(L"ntdll.dll");
    HMODULE gdi = LoadLibraryW(L"gdi32.dll");
    if (load_codepage_table(ntdll)) {
        add_hook(ntdll, "RtlUnicodeToMultiByteN", unicode_to_multi, logfile);
        add_hook(ntdll, "RtlMultiByteToUnicodeN", multi_to_unicode, logfile);
    } else if (logfile) {
        fputs("Japanese NLS table unavailable\n", logfile); fflush(logfile);
    }
    add_hook(kernel, "WideCharToMultiByte", wide_to_multi, logfile);
    add_hook(kernel, "MultiByteToWideChar", multi_to_wide, logfile);
    add_hook(kernel, "IsDBCSLeadByte", is_lead_byte, logfile);
    add_hook(kernel, "GetSystemDefaultLCID", system_lcid, logfile);
    add_hook(kernel, "GetUserDefaultLCID", system_lcid, logfile);
    add_hook(kernel, "GetSystemDefaultLangID", system_langid, logfile);
    add_hook(gdi, "GdiGetCodePage", gdi_codepage, logfile);
    add_hook(kernel, "GetLocaleInfoA", locale_info_a, logfile);
    add_hook(kernel, "GetLocaleInfoW", locale_info_w, logfile);
    SetThreadLocale(0x11);
}
