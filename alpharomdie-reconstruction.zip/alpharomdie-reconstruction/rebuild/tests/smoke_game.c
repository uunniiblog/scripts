#include <windows.h>
#include <stdio.h>

__attribute__((noinline)) static DWORD call_drive(void) {
    return GetDriveTypeA("C:\\\\");
}

int main(void) {
    DWORD drive = call_drive();
    char user[256]; DWORD user_length = sizeof(user);
    if (!GetUserNameA(user, &user_length)) return 3;
    WCHAR japanese[4];
    if (MultiByteToWideChar(CP_ACP, 0, "\x82\xa0", 2, japanese, 4) != 1 ||
        japanese[0] != 0x3042) return 4;
    FILE *f = fopen("smoke_game.ok", "w");
    if (!f) return 2;
    fprintf(f, "drive=%lu user=%s japanese=%04x\n", drive, user, japanese[0]);
    fclose(f);
    return 0;
}
