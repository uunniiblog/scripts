#include <windows.h>
#include <stdio.h>

int main(int argc, char **argv) {
    FILE *started = fopen("hold_game.started", "w");
    if (!started) return 2;
    fprintf(started, "argc=%d arg1=%s\n", argc, argc > 1 ? argv[1] : "");
    fclose(started);
    Sleep(5000);
    FILE *finished = fopen("hold_game.finished", "w");
    if (!finished) return 3;
    fputs("finished\n", finished);
    fclose(finished);
    return 0;
}
