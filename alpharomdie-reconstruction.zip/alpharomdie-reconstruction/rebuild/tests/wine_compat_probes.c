/* Verify that forwarding preserves pointer validation and exception recovery.
 * Build with src/wine_compat.c, then run as a PE32 executable under Wine. */
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stdio.h>
#include "../src/wine_compat.h"

typedef BOOL (WINAPI *Probe)(const void *, UINT_PTR);

int main(void)
{
    HMODULE kernel = GetModuleHandleA("kernel32.dll");
    Probe before[2] = {
        (Probe)(void *)GetProcAddress(kernel, "IsBadReadPtr"),
        (Probe)(void *)GetProcAddress(kernel, "IsBadWritePtr")
    };
    SYSTEM_INFO info;
    GetSystemInfo(&info);
    SIZE_T page = info.dwPageSize;
    BYTE *memory = VirtualAlloc(NULL, page * 3, MEM_RESERVE | MEM_COMMIT, PAGE_READWRITE);
    DWORD old;
    if (!memory || !before[0] || !before[1] ||
        !VirtualProtect(memory + page, page, PAGE_READONLY, &old) ||
        !VirtualProtect(memory + page * 2, page, PAGE_NOACCESS, &old)) return 2;

    struct {
        const char *name;
        const void *address;
        SIZE_T size;
        BOOL bad_read, bad_write;
    } cases[] = {
        {"empty", NULL, 0, FALSE, FALSE},
        {"null", NULL, 1, TRUE, TRUE},
        {"writable", memory, page, FALSE, FALSE},
        {"readonly", memory + page, page, FALSE, TRUE},
        {"inaccessible", memory + page * 2, 1, TRUE, TRUE},
        {"cross readonly", memory + page - 1, 2, FALSE, TRUE},
        {"cross inaccessible", memory + page * 2 - 1, 2, TRUE, TRUE}
    };
    if (!install_wine_compat(stdout)) return 3;
    Probe after[2] = {
        (Probe)(void *)GetProcAddress(kernel, "IsBadReadPtr"),
        (Probe)(void *)GetProcAddress(kernel, "IsBadWritePtr")
    };
    if (!after[0] || !after[1]) return 4;
    if (GetProcAddress(GetModuleHandleA("ntdll.dll"), "wine_get_version") &&
        (before[0] == after[0] || before[1] == after[1])) return 5;
    for (unsigned i = 0; i < sizeof(cases) / sizeof(cases[0]); ++i) {
        for (unsigned p = 0; p < 2; ++p) {
            BOOL expected = p ? cases[i].bad_write : cases[i].bad_read;
            BOOL original = !!before[p](cases[i].address, cases[i].size);
            BOOL forwarded = !!after[p](cases[i].address, cases[i].size);
            if (original != expected || forwarded != expected) {
                fprintf(stderr, "%s probe %u: original=%d forwarded=%d expected=%d\n",
                        cases[i].name, p, original, forwarded, expected);
                return 6;
            }
        }
    }
    VirtualFree(memory, 0, MEM_RELEASE);
    puts("PASS: 14 pointer-probe comparisons, including access-violation recovery");
    return 0;
}
