#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p bin package
CC=i686-w64-mingw32-gcc
COMMON=(-O2 -Wall -Wextra -Werror -m32 -std=gnu11 -Wl,--no-insert-timestamp)
"$CC" "${COMMON[@]}" -shared src/inject.c src/hook.c src/locale.c src/engine.c src/wine_compat.c -o bin/AlphaROMdiE.Inject.dll \
    -Wl,--add-stdcall-alias -Wl,--out-implib,bin/libinject.a -lkernel32
i686-w64-mingw32-windres -i src/helper.rc -o bin/helper-res.o
"$CC" "${COMMON[@]}" -municode src/launcher.c src/patch_pe.c bin/helper-res.o -o bin/AlphaROMdiE-Rebuilt.exe -lshell32
rm -f bin/WineCompat.adp package/Plugin/WineCompat.adp package/AlphaROMdiE-Rebuilt.ini
rmdir package/Plugin 2>/dev/null || true
cp bin/AlphaROMdiE-Rebuilt.exe package/
rm -f package/AlphaROMdiE.Inject.dll
cp README.md package/README.md
file bin/AlphaROMdiE-Rebuilt.exe bin/AlphaROMdiE.Inject.dll
sha256sum package/AlphaROMdiE-Rebuilt.exe bin/AlphaROMdiE.Inject.dll
