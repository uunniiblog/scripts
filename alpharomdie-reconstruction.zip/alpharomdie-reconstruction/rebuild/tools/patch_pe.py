#!/usr/bin/env python3
"""Experimental same-process AlphaROMdiE patcher for PE32 executables."""

from __future__ import annotations

import argparse
import hashlib
import shutil
import struct
from pathlib import Path


def align(value: int, alignment: int) -> int:
    return (value + alignment - 1) // alignment * alignment


def u16(data: bytes, offset: int) -> int:
    return struct.unpack_from("<H", data, offset)[0]


def u32(data: bytes, offset: int) -> int:
    return struct.unpack_from("<I", data, offset)[0]


def patch(game: Path, helper: Path, output: Path) -> Path:
    if output.exists():
        raise ValueError(f"output already exists: {output}")
    if output.parent.resolve() != game.parent.resolve():
        raise ValueError("output must be beside the original game EXE")
    data = bytearray(game.read_bytes())
    if data[:2] != b"MZ":
        raise ValueError("not a PE executable")
    pe = u32(data, 0x3C)
    if data[pe:pe + 4] != b"PE\0\0" or u16(data, pe + 4) != 0x14C:
        raise ValueError("requires a 32-bit x86 PE executable")
    section_count = u16(data, pe + 6)
    optional = pe + 24
    if u16(data, optional) != 0x10B:
        raise ValueError("requires PE32")
    section_header = optional + u16(data, pe + 20)
    sections = []
    for i in range(section_count):
        offset = section_header + i * 40
        virtual_size, virtual_address, raw_size, raw_pointer = struct.unpack_from(
            "<IIII", data, offset + 8
        )
        sections.append((virtual_address, virtual_size, raw_pointer, raw_size))
    if section_header + (section_count + 1) * 40 > min(
        u32(data, optional + 60), min(s[2] for s in sections if s[2])
    ):
        raise ValueError("no room for another PE section header")

    section_alignment = u32(data, optional + 32)
    file_alignment = u32(data, optional + 36)
    if not section_alignment or not file_alignment:
        raise ValueError("invalid PE alignment")
    original_entry = u32(data, optional + 16)
    new_virtual = align(max(v + max(size, raw) for v, size, _, raw in sections), section_alignment)
    new_raw = align(len(data), file_alignment)

    def rva_to_offset(rva: int) -> int:
        for virtual, size, raw, raw_size in sections:
            if virtual <= rva < virtual + max(size, raw_size):
                offset = raw + rva - virtual
                if offset >= len(data):
                    break
                return offset
        raise ValueError(f"unmapped RVA 0x{rva:x}")

    import_rva = u32(data, optional + 104)
    original_imports = bytearray()
    if import_rva:
        import_offset = rva_to_offset(import_rva)
        for i in range(256):
            descriptor = data[import_offset + i * 20:import_offset + (i + 1) * 20]
            if len(descriptor) != 20:
                raise ValueError("truncated import descriptors")
            if descriptor == bytes(20):
                break
            original_imports += descriptor
        else:
            raise ValueError("too many import descriptors")

    dll_bytes = helper.read_bytes()
    dll_name = f"AlphaROMdiE.Inject.{hashlib.sha256(dll_bytes).hexdigest()[:12]}.dll"
    dll_path = output.parent / dll_name
    if dll_path.exists() and dll_path.read_bytes() != dll_bytes:
        raise ValueError(f"conflicting helper: {dll_path}")

    payload = bytearray(31)
    payload += bytes(align(len(payload), 4) - len(payload))
    descriptor_rva = new_virtual + len(payload)
    payload += original_imports
    new_descriptor_offset = len(payload)
    payload += bytes(40)  # Helper import descriptor and terminator.
    lookup_rva = new_virtual + len(payload)
    payload += bytes(8)
    address_rva = new_virtual + len(payload)
    payload += bytes(8)
    dll_name_rva = new_virtual + len(payload)
    payload += dll_name.encode("ascii") + b"\0"
    payload += bytes(align(len(payload), 2) - len(payload))
    hint_name_rva = new_virtual + len(payload)
    payload += b"\0\0Init\0"
    struct.pack_into("<IIIII", payload, new_descriptor_offset,
                     lookup_rva, 0, 0, dll_name_rva, address_rva)
    struct.pack_into("<I", payload, lookup_rva - new_virtual, hint_name_rva)
    struct.pack_into("<I", payload, address_rva - new_virtual, hint_name_rva)

    # PIC x86 entry: preserve registers, call imported Init(NULL), then jump
    # into the game's original entrypoint in the same process.
    stub = bytearray(b"\x9c\x60\xe8\0\0\0\0\x5b\x81\xeb\0\0\0\0"
                     b"\x8b\x83\0\0\0\0\x6a\0\xff\xd0\x61\x9d\xe9\0\0\0\0")
    struct.pack_into("<I", stub, 10, new_virtual + 7)
    struct.pack_into("<I", stub, 16, address_rva)
    struct.pack_into("<i", stub, 27, original_entry - (new_virtual + len(stub)))
    payload[:len(stub)] = stub

    raw_size = align(len(payload), file_alignment)
    header_offset = section_header + section_count * 40
    struct.pack_into("<8sIIIIIIHHI", data, header_offset,
                     b".ardie\0\0", len(payload), new_virtual, raw_size, new_raw,
                     0, 0, 0, 0, 0xE0000060)
    struct.pack_into("<H", data, pe + 6, section_count + 1)
    struct.pack_into("<I", data, optional + 16, new_virtual)
    struct.pack_into("<I", data, optional + 56, align(new_virtual + len(payload), section_alignment))
    struct.pack_into("<II", data, optional + 104, descriptor_rva,
                     len(original_imports) + 40)
    struct.pack_into("<I", data, optional + 64, 0)
    data += bytes(new_raw - len(data)) + payload + bytes(raw_size - len(payload))
    output.write_bytes(data)
    if not dll_path.exists():
        shutil.copyfile(helper, dll_path)
    return dll_path


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("game", type=Path)
    parser.add_argument("--helper", type=Path, default=Path(__file__).resolve().parents[1] / "bin/AlphaROMdiE.Inject.dll")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    game = args.game.resolve()
    output = (args.output or game.with_name(game.stem + ".AlphaROMdiE.native.exe")).resolve()
    print(f"Created {output} with {patch(game, args.helper, output)}")
